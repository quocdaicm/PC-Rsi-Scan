'use strict';
// Đọc/ghi file .zip không cần thư viện ngoài (ghi: lưu nguyên hoặc deflate; đọc: stored + deflate).
const fs = require('fs');
const zlib = require('zlib');

const TABLE = (() => { const t = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
function crc32(buf) { let c = 0xffffffff; for (let i = 0; i < buf.length; i++) c = TABLE[(c ^ buf[i]) & 0xff] ^ (c >>> 8); return (c ^ 0xffffffff) >>> 0; }
function dosDateTime(d) {
  return { time: (d.getHours() << 11) | (d.getMinutes() << 5) | (d.getSeconds() >> 1), date: ((Math.max(d.getFullYear(), 1980) - 1980) << 9) | ((d.getMonth() + 1) << 5) | d.getDate() };
}

class ZipWriter {
  constructor(file) { this.fd = fs.openSync(file, 'w'); this.pos = 0; this.entries = []; }
  _w(b) { fs.writeSync(this.fd, b); this.pos += b.length; }
  add(name, buf, { deflate = false } = {}) {
    const nameBuf = Buffer.from(name, 'utf8'), crc = crc32(buf);
    let data = buf, method = 0;
    if (deflate) { const z = zlib.deflateRawSync(buf); if (z.length < buf.length) { data = z; method = 8; } }
    const { time, date } = dosDateTime(new Date());
    const h = Buffer.alloc(30);
    h.writeUInt32LE(0x04034b50, 0); h.writeUInt16LE(20, 4); h.writeUInt16LE(0x0800, 6); h.writeUInt16LE(method, 8);
    h.writeUInt16LE(time, 10); h.writeUInt16LE(date, 12); h.writeUInt32LE(crc, 14); h.writeUInt32LE(data.length, 18);
    h.writeUInt32LE(buf.length, 22); h.writeUInt16LE(nameBuf.length, 26); h.writeUInt16LE(0, 28);
    const offset = this.pos; this._w(h); this._w(nameBuf); this._w(data);
    this.entries.push({ nameBuf, crc, method, csize: data.length, size: buf.length, offset, time, date });
  }
  close() {
    const start = this.pos;
    for (const e of this.entries) {
      const c = Buffer.alloc(46);
      c.writeUInt32LE(0x02014b50, 0); c.writeUInt16LE(20, 4); c.writeUInt16LE(20, 6); c.writeUInt16LE(0x0800, 8); c.writeUInt16LE(e.method, 10);
      c.writeUInt16LE(e.time, 12); c.writeUInt16LE(e.date, 14); c.writeUInt32LE(e.crc, 16); c.writeUInt32LE(e.csize, 20); c.writeUInt32LE(e.size, 24);
      c.writeUInt16LE(e.nameBuf.length, 28); c.writeUInt32LE(e.offset, 42);
      this._w(c); this._w(e.nameBuf);
    }
    const size = this.pos - start, end = Buffer.alloc(22);
    end.writeUInt32LE(0x06054b50, 0); end.writeUInt16LE(this.entries.length, 8); end.writeUInt16LE(this.entries.length, 10);
    end.writeUInt32LE(size, 12); end.writeUInt32LE(start, 16);
    this._w(end); fs.closeSync(this.fd);
  }
}

// Trả về [{ name, read() }]
function readZip(file) {
  const buf = fs.readFileSync(file);
  let eocd = -1;
  for (let i = buf.length - 22; i >= Math.max(0, buf.length - 65557); i--) if (buf.readUInt32LE(i) === 0x06054b50) { eocd = i; break; }
  if (eocd < 0) throw new Error('Không phải file zip hợp lệ.');
  const count = buf.readUInt16LE(eocd + 10); let p = buf.readUInt32LE(eocd + 16);
  const out = [];
  for (let n = 0; n < count; n++) {
    if (buf.readUInt32LE(p) !== 0x02014b50) throw new Error('File zip bị hỏng.');
    const flags = buf.readUInt16LE(p + 8), method = buf.readUInt16LE(p + 10), csize = buf.readUInt32LE(p + 20);
    const nl = buf.readUInt16LE(p + 28), el = buf.readUInt16LE(p + 30), cl = buf.readUInt16LE(p + 32), off = buf.readUInt32LE(p + 42);
    const name = buf.slice(p + 46, p + 46 + nl).toString(flags & 0x0800 ? 'utf8' : 'latin1');
    out.push({
      name,
      read() {
        const ln = buf.readUInt16LE(off + 26), le = buf.readUInt16LE(off + 28), s = off + 30 + ln + le;
        const raw = buf.slice(s, s + csize);
        if (method === 0) return raw;
        if (method === 8) return zlib.inflateRawSync(raw);
        throw new Error(`Kiểu nén zip ${method} chưa hỗ trợ.`);
      }
    });
    p += 46 + nl + el + cl;
  }
  return out;
}
module.exports = { ZipWriter, readZip, crc32 };
