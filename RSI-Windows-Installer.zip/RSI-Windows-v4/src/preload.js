const { contextBridge, ipcRenderer } = require('electron');
const call = ch => (...a) => ipcRenderer.invoke(ch, ...a);
contextBridge.exposeInMainWorld('rsi', {
  load: call('data:load'),
  getSettings: call('settings:get'),
  setSettings: call('settings:set'),
  getStats: call('stats:get'),
  sync: call('sync:run'),
  openDataFolder: call('app:openDataFolder'),
  clearCache: call('cache:clear'),
  getImage: call('img:get'),
  saveImage: call('img:save'),
  saveAllImages: call('img:saveAll'),
  exportZip: call('export:zip'),
  chooseBackupDir: call('backup:choose'),
  runBackup: call('backup:run'),
  listBackups: call('backup:list'),
  deleteBackup: call('backup:delete'),
  openBackupDir: call('backup:openDir'),
  importFile: call('import:file'),
  clearRestored: call('restore:clear'),
  getLog: call('log:get'),
  clearLog: call('log:clear'),
  onProgress: cb => ipcRenderer.on('task:progress', (_, p) => cb(p)),
  about: call('app:about')
});
