'use strict';
// Logic tìm kiếm / ngày tháng / tổng hợp mã kiện được port từ bản iOS
// (Search.swift, MonthFilter.swift, Model.swift: SlipDate, History.swift).

let slips = [];
let selectedMonth = null;      // null = tất cả; số = year*100+month
let monthInit = false;
let showSuggest = true;

const $ = s => document.querySelector(s);
const ico = (body, size = 18, sw = 2) => `<svg class="ic" viewBox="0 0 24 24" width="${size}" height="${size}" fill="none" stroke="currentColor" stroke-width="${sw}" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${body}</svg>`;
const ICON_PREV = ico('<path d="M15 6l-6 6 6 6"/>');
const ICON_NEXT = ico('<path d="M9 6l6 6-6 6"/>');
const ICON_DL = ico('<path d="M12 4v11M7.5 11L12 15.5 16.5 11M5 20h14"/>');
const ICON_X = ico('<path d="M6 6l12 12M18 6L6 18"/>');
const KIND_ICON = {
  rsi: ico('<rect x="4" y="3" width="16" height="18" rx="3"/><path d="M8 8h8M8 12h8M8 16h5"/>', 16, 1.8),
  package: ico('<path d="M12 3l8 4.5v9L12 21l-8-4.5v-9L12 3z"/><path d="M4 7.5l8 4.5 8-4.5M12 12v9"/>', 16, 1.8),
  desc: ico('<path d="M4 7h16M4 12h16M4 17h10"/>', 16, 1.8)
};
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

// ---------- Ảnh Drive ----------
function driveFileUrl(id, mode = 'view') { return id ? `https://drive.google.com/uc?export=${mode}&id=${encodeURIComponent(id)}` : ''; }
function pageUrl(s, name) { if (/^https?:\/\//i.test(String(name || ''))) return name; const id = (s.driveImages || {})[name]; return driveFileUrl(id, 'view'); }

// ---------- Fuzzy (giống Fuzzy trong Search.swift) ----------
const Fuzzy = {
  norm(s) { return String(s ?? '').normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/đ/gi, 'd').toLowerCase(); },
  words(s) { return Fuzzy.norm(s).split(/[^a-z0-9]+/).filter(Boolean); },
  lev(a, b) {
    if (!a.length) return b.length; if (!b.length) return a.length;
    let p = Array.from({ length: b.length + 1 }, (_, i) => i);
    for (let i = 1; i <= a.length; i++) {
      const c = [i];
      for (let j = 1; j <= b.length; j++) c[j] = Math.min(p[j] + 1, c[j - 1] + 1, p[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
      p = c;
    }
    return p[b.length];
  },
  maxDist(n) { return n >= 7 ? 2 : (n >= 4 ? 1 : 0); },
  isSubsequence(q, t) { let i = 0; for (const c of t) { if (c === q[i]) i++; if (i === q.length) return true; } return q.length === 0; },
  // 0 = không khớp; 110/100 chứa nguyên cụm; 85 chứa đủ các từ; 60 gần đúng; 40 rải rác (chỉ cho mã)
  score(query, text, subsequence = false) {
    const qw = Fuzzy.words(query), q = qw.join(''); if (!q) return 0;
    const tw = Fuzzy.words(text), t = tw.join(''); if (!t) return 0;
    if (t.includes(q)) return t.startsWith(q) ? 110 : 100;
    if (qw.length > 1 && qw.every(w => t.includes(w))) return 85;
    let allOK = true;
    for (const tok of qw) {
      if (t.includes(tok)) continue;
      const d = Fuzzy.maxDist(tok.length);
      if (d === 0 || /^\d+$/.test(tok)) { allOK = false; break; }   // số thì phải đúng
      const ok = tw.some(w => {
        if (Math.abs(w.length - tok.length) <= d && Fuzzy.lev(tok, w) <= d) return true;
        if (w.length > tok.length && Fuzzy.lev(tok, w.slice(0, tok.length)) <= d) return true;
        return false;
      });
      if (!ok) { allOK = false; break; }
    }
    if (allOK) return 60;
    if (subsequence && q.length >= 4 && Fuzzy.isSubsequence(q, t)) return 40;
    return 0;
  }
};

// ---------- Ngày (giống SlipDate + monthKey + slipsNewestFirst) ----------
const MONTHS = ['jan', 'feb', 'mar', 'apr', 'may', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec'];
function mkDate(y, m, d) {
  if (y < 100) y += 2000;
  if (m < 1 || m > 12 || d < 1 || d > 31) return null;
  const dt = new Date(y, m - 1, d);
  return dt.getMonth() === m - 1 && dt.getDate() === d ? dt : null;
}
function parseSlipDate(str) {
  const t = String(str ?? '').trim(); if (!t) return null;
  let m;
  if ((m = t.match(/^(\d{4})-(\d{1,2})-(\d{1,2})$/))) return mkDate(+m[1], +m[2], +m[3]);
  if ((m = t.match(/^(\d{1,2})[-\s]([A-Za-z]{3,9})[-\s,]*(\d{2}|\d{4})$/))) {
    const mi = MONTHS.indexOf(m[2].slice(0, 3).toLowerCase());
    return mi >= 0 ? mkDate(+m[3], mi + 1, +m[1]) : null;
  }
  if ((m = t.match(/^(\d{1,2})[\/.\-](\d{1,2})[\/.\-](\d{2}|\d{4})$/))) return mkDate(+m[3], +m[2], +m[1]);   // ngày trước tháng
  return null;
}
function createdDate(s) {
  const c = s.createdAt;
  if (typeof c === 'number') return new Date((c + 978307200) * 1000);      // Swift Date: giây từ 2001-01-01
  if (typeof c === 'string' && c) { const d = new Date(c); if (!isNaN(d)) return d; }
  return new Date(0);
}
const slipDate = s => parseSlipDate(s.requestDate) || createdDate(s);
const monthId = s => { const d = slipDate(s); return d.getFullYear() * 100 + d.getMonth() + 1; };
const monthShort = id => `${id % 100}/${Math.floor(id / 100)}`;
const monthTitle = id => `Tháng ${id % 100}/${Math.floor(id / 100)}`;
function nowMonthId() { const d = new Date(); return d.getFullYear() * 100 + d.getMonth() + 1; }
function slipsNewestFirst(list = slips) {
  return list.map(s => [s, slipDate(s)]).sort((a, b) => (a[1] - b[1] !== 0 ? b[1] - a[1] : createdDate(b[0]) - createdDate(a[0]))).map(x => x[0]);
}
function monthCounts() {
  const c = new Map([[nowMonthId(), 0]]);
  for (const s of slips) { const k = monthId(s); c.set(k, (c.get(k) || 0) + 1); }
  return [...c.entries()].sort((a, b) => b[0] - a[0]);
}

// ---------- Tìm kiếm (giống Store.hits trong Search.swift) ----------
function itemScore(q, it) {
  return Math.max(Fuzzy.score(q, it.packageNo, true), Fuzzy.score(q, it.desc), Fuzzy.score(q, it.tag));
}
function hits(q) {
  const t = q.trim(), base = slipsNewestFirst();
  if (!t) return base.map(s => ({ s, items: [], score: 0 }));
  const out = [];
  base.forEach((s, idx) => {
    const rsiScore = Fuzzy.score(t, s.rsiNo, true);
    let best = rsiScore;
    for (const f of [s.requestDate, s.project, s.remark]) {
      const sc = Fuzzy.score(t, f); if (sc >= 85) best = Math.max(best, sc - 20);
    }
    let matched = [];
    for (const it of s.items) { const sc = itemScore(t, it); if (sc > 0) matched.push([it, sc]); }
    matched.sort((a, b) => b[1] - a[1]);
    if (matched.length) {
      best = Math.max(best, matched[0][1]);
      const minScore = rsiScore >= 100 ? 85 : Math.min(matched[0][1], 85);
      matched = matched.filter(x => x[1] >= minScore);
    }
    if (best > 0) out.push({ s, items: matched.map(x => x[0]), score: best, idx });
  });
  return out.sort((a, b) => (a.score !== b.score ? b.score - a.score : a.idx - b.idx));
}
const onlyWithMatchedItems = hs => (hs.some(h => h.items.length) ? hs.filter(h => h.items.length) : hs);

// ---------- Lịch sử xuất / tổng hợp mã kiện (History.swift) ----------
const key = x => String(x ?? '').trim().toUpperCase();
const sameGoods = (a, b) => !!key(a.packageNo) && key(a.packageNo) === key(b.packageNo) && key(a.tag) === key(b.tag);
const qtyValue = it => { const n = Number(String(it.qty ?? '').trim().replace(',', '.')); return String(it.qty ?? '').trim() !== '' && isFinite(n) ? n : null; };
const formatQty = v => (Number.isInteger(v) ? String(v) : v.toFixed(2));
function totalsText(recs) {
  const sums = new Map();
  for (const r of recs) { const v = qtyValue(r.item); if (v === null) continue; const u = key(r.item.unit); sums.set(u, (sums.get(u) || 0) + v); }
  return sums.size ? [...sums].map(([u, v]) => `${formatQty(v)} ${u}`.trim()).join(', ') : '-';
}
function historyFor(item) {
  const out = [];
  for (const s of slipsNewestFirst()) for (const x of s.items) if (sameGoods(x, item)) out.push({ slip: s, item: x });
  return out;
}
function packageSummaries(q, hs) {
  const t = q.trim(); if (!t) return [];
  const qKey = Fuzzy.words(t).join('');
  const order = [], groups = new Map();
  for (const h of hs) for (const it of h.items) {
    if (Fuzzy.score(t, it.packageNo) < 85) continue;
    const k = Fuzzy.words(it.packageNo).join('');
    if (!groups.has(k)) { order.push(k); groups.set(k, { item: it, recs: [] }); }
    groups.get(k).recs.push({ slip: h.s, item: it });
  }
  if (groups.has(qKey)) {       // mã đọc sai do OCR gộp vào đúng mã đang tìm
    for (const k of [...order]) if (k !== qKey && k.includes(qKey)) { groups.get(qKey).recs.push(...groups.get(k).recs); groups.delete(k); }
  }
  return order.filter(k => groups.has(k)).map(k => groups.get(k));
}

// ---------- Gợi ý (Store.suggestions) ----------
function suggestions(q, limit = 6) {
  const t = q.trim(); if (!t) return [];
  const seen = new Set(), list = [];
  for (const s of slipsNewestFirst()) {
    const r = Fuzzy.score(t, s.rsiNo, true);
    if (r > 0 && !seen.has('r-' + key(s.rsiNo))) {
      seen.add('r-' + key(s.rsiNo));
      list.push({ kind: 'rsi', text: s.rsiNo, sub: `${s.items.length} kiện` + (s.requestDate ? ` · ${s.requestDate}` : ''), score: r + 8 });
    }
    for (const it of s.items) {
      const p = Fuzzy.score(t, it.packageNo, true), pk = `p-${s.id}-${key(it.packageNo)}`;
      if (p > 0 && !seen.has(pk)) { seen.add(pk); list.push({ kind: 'package', text: it.packageNo, sub: `trong ${s.rsiNo}` + (it.qty ? ` · ${it.qty} ${it.unit}` : ''), score: p + 4 }); }
      if (it.desc) {
        const d = Fuzzy.score(t, it.desc), dk = `d-${s.id}-${key(it.desc)}`;
        if (d > 0 && !seen.has(dk)) { seen.add(dk); list.push({ kind: 'desc', text: it.desc, sub: `trong ${s.rsiNo} · ${it.packageNo}`, score: d }); }
      }
    }
  }
  return list.map((x, i) => [x, i]).sort((a, b) => (a[0].score !== b[0].score ? b[0].score - a[0].score : a[1] - b[1])).slice(0, limit).map(x => x[0]);
}

// ---------- Tô sáng (highlighted trong Search.swift) ----------
function highlight(text, q) {
  const s = String(text ?? ''), t = q.trim();
  if (!t) return esc(s);
  const fold = c => c.normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/đ/gi, 'd').toLowerCase();
  const chars = [...s], folded = chars.map(fold);
  if (folded.some(f => f.length !== 1)) return esc(s);
  const i = folded.join('').indexOf(fold(t));
  if (i < 0 || fold(t).length !== [...t].length) return esc(s);
  const n = [...t].length;
  return esc(chars.slice(0, i).join('')) + '<mark>' + esc(chars.slice(i, i + n).join('')) + '</mark>' + esc(chars.slice(i + n).join(''));
}

// ---------- Giao diện ----------
function matchRows(items, q) {
  if (!items.length) return '';
  return `<div class="items"><div class="itemsTitle">Kiện hàng khớp</div>${items.slice(0, 3).map(i => `<div class="item"><span><b>${highlight(i.packageNo, q)}</b><br>${highlight(i.desc, q)}</span><b>${esc(i.qty)} ${esc(i.unit)}${i.actualQty ? ` · nhận ${esc(i.actualQty)}` : ''}</b></div>`).join('')}${items.length > 3 ? `<div class="muted">+${items.length - 3} kiện khớp khác</div>` : ''}</div>`;
}
function card(s, items = [], q = '') {
  return `<div class="card" data-id="${esc(s.id)}"><div class="rowtop"><div><div class="rsi">${highlight(s.rsiNo || 'Chưa có số RSI', q)}</div><div class="muted">${esc(s.requestDate || '-')}${s.project ? ' · ' + esc(s.project) : ''}</div></div><div class="countPill">${(s.items || []).length} kiện · ${(s.pages || []).length} ảnh</div></div>${s.remark ? `<div class="remark">${esc(s.remark)}</div>` : ''}${items.length ? matchRows(items, q) : `<div class="tags">${(s.items || []).slice(0, 6).map(i => `<span class="tag">${esc(i.packageNo || i.tag || i.desc)}</span>`).join('')}</div>`}</div>`;
}
function summaryCard(sm, idx) {
  const it = sm.item;
  return `<div class="sumCard" data-sum="${idx}"><div class="sumPkg">${esc(it.packageNo)}</div>${it.desc ? `<div class="sumDesc">${esc(it.desc)}</div>` : ''}${it.tag ? `<span class="sumTag">${esc(it.tag)}</span>` : ''}<div class="sumLine">Đã xuất ${sm.recs.length} lần · tổng ${esc(totalsText(sm.recs))} <span>${ICON_NEXT}</span></div></div>`;
}
let lastSummaries = [];

function renderChips() {
  const counts = monthCounts();
  $('#chips').innerHTML = counts.map(([id, n]) => `<button class="chip${selectedMonth === id ? ' active' : ''}" data-m="${id}">${monthShort(id)} <i>${n}</i></button>`).join('')
    + `<button class="chip${selectedMonth === null ? ' active' : ''}" data-m="">Tất cả <i>${slips.length}</i></button>`;
}
function render() {
  const q = $('#search').value, searching = !!q.trim();
  let hs = hits(q);
  if (searching) hs = onlyWithMatchedItems(hs);
  else if (selectedMonth !== null) hs = hs.filter(h => monthId(h.s) === selectedMonth);
  lastSummaries = searching ? packageSummaries(q, hs) : [];
  $('#summaries').innerHTML = lastSummaries.slice(0, 3).map(summaryCard).join('') + (lastSummaries.length > 3 ? `<div class="muted">+${lastSummaries.length - 3} loại kiện khớp khác</div>` : '');
  $('#hitCount').textContent = searching ? `${hs.length} phiếu khớp` : '';
  const emptyMsg = slips.length ? (searching ? 'Thử số RSI, mã kiện hoặc tên vật tư khác.' : `Không có phiếu trong ${selectedMonth !== null ? monthTitle(selectedMonth) : 'danh sách'}. Chọn "Tất cả" để xem mọi tháng.`) : 'Đang chờ dữ liệu. Kiểm tra mạng rồi bấm Đồng bộ.';
  $('#results').innerHTML = hs.length ? hs.map(h => card(h.s, h.items, q)).join('') : `<div class="empty"><div class="emptyIcon"><svg class="ic" viewBox="0 0 24 24" width="36" height="36" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="11" cy="11" r="6.5"/><path d="M20 20l-4.2-4.2"/></svg></div><b>Không tìm thấy dữ liệu</b><p>${esc(emptyMsg)}</p></div>`;
  $('#count').textContent = `${slips.length} phiếu`;
  renderChips();
  renderSuggest();
}
function renderSuggest() {
  const q = $('#search').value, list = showSuggest ? suggestions(q) : [];
  const label = { rsi: 'Số RSI', package: 'Mã kiện', desc: 'Tên hàng' };
  $('#suggest').classList.toggle('hidden', !list.length);
  $('#suggest').innerHTML = list.length ? `<div class="sgTitle">Gợi ý</div>` + list.map((g, i) => `<button class="sg" data-i="${i}"><span class="sgIc">${KIND_ICON[g.kind]}</span><span class="sgTx"><b>${highlight(g.text, q)}</b><small>${label[g.kind]} · ${esc(g.sub)}</small></span></button>`).join('') : '';
  $('#suggest')._list = list;
}
function historyModal(item, backSlip) {
  const recs = historyFor(item);
  $('#modal').classList.remove('hidden');
  $('#modal').innerHTML = `<div class="modalbox"><button class="close" id="closeModal" aria-label="Đóng">${ICON_X}</button>${backSlip ? '<button class="back" id="backSlip">' + ICON_PREV + 'Quay lại phiếu ' + esc(backSlip.rsiNo) + '</button>' : ''}<div class="detailHead"><div><div class="eyebrow">LỊCH SỬ XUẤT</div><h2>${esc(item.packageNo)}</h2><p class="muted">${esc(item.desc)}${item.tag ? ' · Tag: ' + esc(item.tag) : ''}</p></div></div><div class="note">Đã xuất ${recs.length} lần · tổng ${esc(totalsText(recs))}</div><h3>Từng lần xuất theo RSI</h3><div class="itemTable">${recs.map(r => `<div class="detailItem hist" data-id="${esc(r.slip.id)}"><div><b>${esc(r.slip.rsiNo || '(chưa có số)')}</b><span>${esc(r.slip.requestDate || '-')}</span></div><strong>${esc(r.item.qty)} ${esc(r.item.unit)}</strong></div>`).join('')}</div></div>`;
  $('#closeModal').onclick = () => $('#modal').classList.add('hidden');
  if (backSlip) $('#backSlip').onclick = () => detail(backSlip);
}
function detail(s) {
  const pages = (s.pages || []);
  $('#modal').classList.remove('hidden');
  $('#modal').innerHTML = `<div class="modalbox"><button class="close" id="closeModal" aria-label="Đóng">${ICON_X}</button><div class="detailHead"><div><div class="eyebrow">PHIẾU RSI</div><h2>${esc(s.rsiNo || 'Chưa có số RSI')}</h2><p class="muted">${esc(s.requestDate || '-')}${s.project ? ' · ' + esc(s.project) : ''}</p></div><div class="detailStat"><b>${(s.items || []).length}</b><span>kiện</span></div><div class="detailStat"><b>${pages.length}</b><span>ảnh</span></div></div>${s.remark ? `<div class="note">${esc(s.remark)}</div>` : ''}<h3>Kiện hàng</h3><div class="itemTable">${(s.items || []).map((i, k) => { const n = i.packageNo ? historyFor(i).length : 0; return `<div class="detailItem${n ? ' link' : ''}" data-k="${k}"><div><b>${esc(i.packageNo || '(chưa có mã)')}</b><span>${esc(i.desc)}</span>${i.tag ? `<small>Tag: ${esc(i.tag)}</small>` : ''}</div><strong>${esc(i.qty)} ${esc(i.unit)}${i.actualQty ? `<small>Nhận: ${esc(i.actualQty)}</small>` : ''}</strong>${n ? `<em class="chev">${n > 1 ? 'Xuất ' + n + ' lần ' : ''}${ICON_NEXT}</em>` : ''}</div>`; }).join('') || '<div class="empty">Không có kiện hàng.</div>'}</div><h3>Thông tin xác nhận</h3><div class="people">${[['Người nhận', s.receivedBy], ['Ngày nhận', s.receivedDate], ['Requested By', s.requestedBy], ['Checked By', s.checkedBy], ['Confirmed By', s.confirmedBy], ['Approved By', s.approvedBy]].filter(x => x[1]).map(x => `<div><span>${esc(x[0])}</span><b>${esc(x[1])}</b></div>`).join('') || '<span class="muted">Không có dữ liệu.</span>'}</div><div class="galHead"><h3>Ảnh phiếu</h3>${pages.length > 1 ? '<button id="saveAll">Tải tất cả ảnh</button>' : ''}</div><div class="gallery">${pages.map((u, i) => { const src = imgSrc(s, u); return src ? `<button class="thumb" data-i="${i}"><span class="ph">Đang tải ảnh…</span><span class="cap">Trang ${i + 1}</span></button>` : `<div class="broken"><span>Trang ${i + 1} (chưa có trên Drive)</span></div>`; }).join('') || '<div class="muted">Không có ảnh.</div>'}</div></div>`;
  $('#closeModal').onclick = () => $('#modal').classList.add('hidden');
  document.querySelectorAll('#modal .detailItem.link').forEach(el => { el.onclick = () => historyModal(s.items[+el.dataset.k], s); });
  hookGallery(s);
}
// ---------- Ảnh phiếu: tự tải về máy, xem phóng to, lưu ----------
const imgSrc = (s, name) => ((s.localImages || {})[name] ? 'local:' + s.localImages[name] : /^https?:\/\//i.test(String(name || '')) ? name : ((s.driveImages || {})[name] || ''));
const imgCache = new Map();            // src -> dataUrl
const imgName = (s, i) => `${s.rsiNo || 'phieu'}_trang${i + 1}`;
async function getImg(src) {
  if (imgCache.has(src)) return { ok: true, dataUrl: imgCache.get(src) };
  const r = await window.rsi.getImage(src);
  if (r.ok) imgCache.set(src, r.dataUrl);
  return r;
}
async function loadThumb(s, btn) {
  const i = +btn.dataset.i, src = imgSrc(s, s.pages[i]);
  btn.querySelector('.ph, img, .err')?.remove();
  const ph = document.createElement('span'); ph.className = 'ph'; ph.textContent = 'Đang tải ảnh…'; btn.prepend(ph);
  const r = await getImg(src);
  if (!btn.isConnected) return;
  ph.remove();
  if (r.ok) { const im = document.createElement('img'); im.src = r.dataUrl; im.alt = `Trang ${i + 1}`; btn.prepend(im); btn.classList.remove('failed'); }
  else { const e = document.createElement('span'); e.className = 'err'; e.textContent = `${r.message || 'Không tải được ảnh'}. Bấm để thử lại.`; btn.prepend(e); btn.classList.add('failed'); }
}
function hookGallery(s) {
  const btns = [...document.querySelectorAll('#modal .thumb')];
  btns.forEach(b => { b.onclick = () => (b.classList.contains('failed') ? loadThumb(s, b) : openViewer(s, +b.dataset.i)); });
  (async () => { for (const b of btns) await loadThumb(s, b); })();     // tải lần lượt từng ảnh
  const all = $('#saveAll');
  if (all) all.onclick = async () => {
    all.disabled = true; all.textContent = 'Đang tải…';
    const r = await window.rsi.saveAllImages(s.pages.map((u, i) => ({ src: imgSrc(s, u), name: imgName(s, i) })).filter(x => x.src));
    all.disabled = false; all.textContent = r.ok ? `Đã lưu ${r.count} ảnh` : (r.canceled ? 'Tải tất cả ảnh' : (r.message || 'Không lưu được'));
    setTimeout(() => { if (all.isConnected) all.textContent = 'Tải tất cả ảnh'; }, 3000);
  };
}
let viewer = null;
function closeViewer() { if (viewer) { viewer.remove(); viewer = null; } }
function openViewer(s, idx) {
  closeViewer();
  const n = s.pages.length; let i = idx, zoom = false;
  viewer = document.createElement('div'); viewer.className = 'viewer';
  viewer.innerHTML = '<div class="vbar"><button id="vprev" aria-label="Trang trước">'+ICON_PREV+'</button><span id="vtitle"></span><button id="vnext" aria-label="Trang sau">'+ICON_NEXT+'</button><span class="vgap"></span><button id="vsave" class="primary">'+ICON_DL+'<span id="vsl">Tải ảnh về</span></button><button id="vclose" aria-label="Đóng">'+ICON_X+'</button></div><div class="vstage"><img id="vimg" alt=""><div id="vmsg" class="vmsg"></div></div>';
  document.body.appendChild(viewer);
  const img = viewer.querySelector('#vimg'), msg = viewer.querySelector('#vmsg'), stage = viewer.querySelector('.vstage');
  async function show1() {
    viewer.querySelector('#vtitle').textContent = `${s.rsiNo || 'Phiếu'} · Trang ${i + 1}/${n}`;
    viewer.querySelector('#vprev').disabled = i === 0; viewer.querySelector('#vnext').disabled = i === n - 1;
    zoom = false; img.className = ''; img.removeAttribute('src'); msg.textContent = 'Đang tải ảnh…';
    const my = i, r = await getImg(imgSrc(s, s.pages[i]));
    if (my !== i || !viewer) return;
    if (r.ok) { msg.textContent = ''; img.src = r.dataUrl; } else msg.textContent = r.message || 'Không tải được ảnh';
  }
  img.onclick = () => { zoom = !zoom; img.className = zoom ? 'zoom' : ''; stage.scrollTo(0, 0); };
  viewer.querySelector('#vprev').onclick = () => { if (i > 0) { i--; show1(); } };
  viewer.querySelector('#vnext').onclick = () => { if (i < n - 1) { i++; show1(); } };
  viewer.querySelector('#vclose').onclick = closeViewer;
  viewer.querySelector('#vsave').onclick = async e => {
    const b = e.currentTarget, l = b.querySelector('#vsl'); b.disabled = true;
    const r = await window.rsi.saveImage(imgSrc(s, s.pages[i]), imgName(s, i));
    l.textContent = r.ok ? 'Đã lưu' : (r.canceled ? 'Tải ảnh về' : (r.message || 'Không lưu được'));
    b.disabled = false;
    setTimeout(() => { if (b.isConnected) l.textContent = 'Tải ảnh về'; }, 2500);
  };
  show1();
}
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') { if (viewer) closeViewer(); else $('#modal').classList.add('hidden'); }
  if (viewer && e.key === 'ArrowLeft') viewer.querySelector('#vprev').click();
  if (viewer && e.key === 'ArrowRight') viewer.querySelector('#vnext').click();
});

function show(view) {
  document.querySelectorAll('.view').forEach(v => v.classList.add('hidden'));
  $(`#${view}View`).classList.remove('hidden');
  document.querySelectorAll('.nav').forEach(n => n.classList.toggle('active', n.dataset.view === view));
  $('#pageTitle').textContent = view === 'home' ? 'Tra cứu RSI' : view === 'all' ? 'Danh sách phiếu' : 'Cài đặt';
  $('#pageSub').textContent = view === 'settings' ? 'Nguồn dữ liệu, sao lưu, nhật ký' : 'Tìm phiếu, mã kiện và thông tin vật tư';
}
function setSync(t, err = false) { $('#syncText').textContent = t; $('#syncDot').classList.toggle('error', err); $('#syncDot').classList.toggle('busy', !err && /Đang/.test(t)); }
function buildMonths() {
  const ids = [...new Set(slips.map(monthId))].sort((a, b) => b - a), cur = $('#monthFilter').value;
  $('#monthFilter').innerHTML = '<option value="">Tất cả tháng</option>' + ids.map(m => `<option value="${m}">${monthTitle(m)}</option>`).join('');
  $('#monthFilter').value = ids.map(String).includes(cur) ? cur : '';
}
function renderAll() {
  const q = Fuzzy.words($('#listSearch').value).join(''), m = $('#monthFilter').value;
  const a = slipsNewestFirst().filter(s => (!q || [s.rsiNo, s.project, s.requestDate, s.remark].some(v => Fuzzy.words(v).join('').includes(q))) && (!m || monthId(s) === +m));
  $('#allList').innerHTML = a.map(s => card(s)).join('') || '<div class="empty">Không có phiếu.</div>';
  $('#listCount').textContent = `${a.length}/${slips.length}`;
}
function refreshAll() {
  if (!monthInit) { selectedMonth = nowMonthId(); monthInit = true; }   // mặc định tháng hiện tại như bản iPhone
  buildMonths(); render(); renderAll();
}
async function sync() {
  setSync('Đang đồng bộ…');
  let r;
  try { r = await window.rsi.sync(); } catch (e) { r = { ok: false, message: e.message }; }
  if (r.ok) { slips = await window.rsi.load(); setSync(`Đã đồng bộ · ${r.count} phiếu`); refreshAll(); }
  else setSync(slips.length ? `Không đồng bộ được, đang dùng dữ liệu đã lưu (${r.message})` : r.message, true);
}

(async () => {
  slips = await window.rsi.load();
  const st = await window.rsi.getSettings();
  if (st.lastSync) setSync('Đồng bộ ' + new Date(st.lastSync).toLocaleString('vi-VN'));
  else setSync(slips.length ? 'Đang dùng dữ liệu trên máy' : 'Chưa có dữ liệu');
  refreshAll();
  if (st.autoSync !== false) sync();   // tự đồng bộ mỗi lần mở app, không cần khách thao tác

  document.querySelectorAll('.nav').forEach(n => n.onclick = () => show(n.dataset.view));
  $('#search').oninput = () => { showSuggest = true; render(); };
  $('#clear').onclick = () => { $('#search').value = ''; showSuggest = true; render(); };
  $('#chips').onclick = e => { const b = e.target.closest('.chip'); if (!b) return; selectedMonth = b.dataset.m === '' ? null : +b.dataset.m; render(); };
  $('#suggest').onclick = e => {
    const b = e.target.closest('.sg'); if (!b) return;
    $('#search').value = $('#suggest')._list[+b.dataset.i].text; showSuggest = false; render();
  };
  $('#summaries').onclick = e => { const c = e.target.closest('.sumCard'); if (c) historyModal(lastSummaries[+c.dataset.sum].item); };
  $('#syncBtn').onclick = sync;
  $('#listSearch').oninput = renderAll;
  $('#monthFilter').onchange = renderAll;
  document.addEventListener('click', e => {
    const h = e.target.closest('.hist'), c = e.target.closest('.card');
    const id = h ? h.dataset.id : c ? c.dataset.id : null;
    if (id === null) return;
    const s = slips.find(x => String(x.id) === id); if (s) detail(s);
  });

  const fmtBytes = n => (n < 1024 * 1024 ? `${Math.round(n / 1024)} KB` : `${(n / 1024 / 1024).toFixed(1)} MB`);
  const msg = (t, ok) => { $('#adminMsg').innerHTML = `<div class="msg ${ok ? 'ok' : 'err'}">${esc(t)}</div>`; setTimeout(() => { if ($('#adminMsg').textContent === t) $('#adminMsg').innerHTML = ''; }, 3500); };
  const fmtTime = iso => (iso ? new Date(iso).toLocaleString('vi-VN') : '-');
  const KIND = {
    created: ['Tạo phiếu', '#168456', '<path d="M12 5v14M5 12h14"/>', 'phieu'],
    edited: ['Đã sửa', '#c77a12', '<path d="M4 20l4-1 11-11-3-3L5 16l-1 4z"/>', 'phieu'],
    deleted: ['Đã xóa', '#c0434c', '<path d="M4 7h16M6 7l1 12a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2l1-12M9 7V4h6v3"/>', 'phieu'],
    synced: ['Đồng bộ', '#2f6fd1', '<path d="M20 11a8 8 0 0 0-14.5-4.5L4 8M4 4v4h4M4 13a8 8 0 0 0 14.5 4.5L20 16M20 20v-4h-4"/>', 'dongbo'],
    failed: ['Lỗi', '#c0434c', '<path d="M12 8v5M12 17h.01"/><circle cx="12" cy="12" r="9"/>', 'loi'],
    config: ['Cài đặt', '#5f6e66', '<path d="M4 7h9M17 7h3M4 17h3M11 17h9"/><circle cx="15" cy="7" r="2"/><circle cx="9" cy="17" r="2"/>', 'caidat'],
    export: ['Xuất zip', '#0f8a7a', '<path d="M12 4v11M7.5 11L12 15.5 16.5 11M5 20h14"/>', 'sao'],
    backup: ['Sao lưu', '#0f8a7a', '<path d="M12 4v11M7.5 11L12 15.5 16.5 11M5 20h14"/>', 'sao'],
    restore: ['Khôi phục', '#0f8a7a', '<path d="M12 20V9M7.5 13L12 8.5 16.5 13M5 4h14"/>', 'sao']
  };
  const LOG_FILTERS = [['', 'Tất cả'], ['phieu', 'Phiếu'], ['dongbo', 'Đồng bộ'], ['sao', 'Sao lưu'], ['loi', 'Lỗi'], ['caidat', 'Cài đặt']];
  let logEntries = [], logFilter = '';
  const renderLog = () => {
    $('#logChips').innerHTML = LOG_FILTERS.map(([k, t]) => `<button class="chip${logFilter === k ? ' active' : ''}" data-k="${k}">${t}</button>`).join('');
    const list = logEntries.filter(e => !logFilter || (KIND[e.kind] || [])[3] === logFilter);
    $('#logList').innerHTML = list.length ? list.slice(0, 200).map(e => { const k = KIND[e.kind] || ['Khác', '#5f6e66', '<circle cx="12" cy="12" r="3"/>'];
      return `<div class="logRow"><span class="logIc" style="--c:${k[1]}">${ico(k[2], 16, 2)}</span><div class="logTx"><b>${esc(k[0])}${e.rsi ? ' · ' + esc(e.rsi) : ''}</b>${e.detail ? `<small>${esc(e.detail)}</small>` : ''}</div><time>${esc(fmtTime(e.date))}</time></div>`; }).join('')
      : '<div class="muted logEmpty">Chưa có thao tác nào.</div>';
  };
  const loadLog = async () => { const r = await window.rsi.getLog(); logEntries = r.ok ? r.entries : []; $('#logCount').textContent = `${logEntries.length} dòng`; renderLog(); };
  const renderBackups = async () => {
    const r = await window.rsi.listBackups(), files = r.ok ? r.files : [];
    $('#bkList').innerHTML = files.map(f => `<div class="row bkRow"><span>${esc(f.name)}<small>${esc(fmtTime(f.time))} · ${fmtBytes(f.size)}</small></span><button class="danger sm" data-n="${esc(f.name)}" aria-label="Xóa bản sao lưu">${ico('<path d="M4 7h16M6 7l1 12a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2l1-12M9 7V4h6v3"/>', 16)}</button></div>`).join('');
  };
  const fillStats = async () => {
    const st = await window.rsi.getStats(); if (!st.ok) return;
    $('#stSource').textContent = st.usingBuiltIn ? 'Nguồn cài sẵn' : 'Link do admin nhập';
    $('#stLast').textContent = st.lastSync ? fmtTime(st.lastSync) : 'Chưa đồng bộ';
    $('#stCount').textContent = `${st.slips} phiếu / ${st.pages} ảnh`;
    $('#stVer').textContent = st.dataVersion || '-';
    $('#stCache').textContent = fmtBytes(st.cacheBytes); $('#stCacheN').textContent = `${st.cacheCount} ảnh`;
    $('#autoSync').checked = st.autoSync; $('#autoBackup').checked = st.autoBackup;
    $('#bkDir').textContent = st.backupDir || 'Chưa chọn'; $('#bkDir').title = st.backupDir || '';
    $('#bkLast').textContent = st.lastBackup ? fmtTime(st.lastBackup) : 'Chưa sao lưu';
    document.querySelectorAll('#bkDays button').forEach(b => b.classList.toggle('on', +b.dataset.d === st.backupDays));
    $('#stRestored').textContent = `${st.restored} phiếu`; $('#restoredBtn').classList.toggle('hidden', !st.restored);
    $('#appVer').textContent = `Phiên bản ${st.appVersion || ''}`.trim();
    await renderBackups(); await loadLog();
  };
  const loadSettings = async () => { const st = await window.rsi.getSettings(); $('#manifestUrl').value = st.manifestUrl || ''; await fillStats(); };
  await loadSettings();
  $('#saveSettings').onclick = async () => {
    const r = await window.rsi.setSettings({ manifestUrl: $('#manifestUrl').value });
    msg(r.ok ? 'Đã lưu link nguồn dữ liệu.' : r.message, r.ok); if (r.ok) fillStats();
  };
  $('#clearCache').onclick = async e => {
    const b = e.currentTarget;
    if (!b.dataset.sure) { b.dataset.sure = '1'; b.lastChild.textContent = 'Bấm lần nữa để xóa'; setTimeout(() => { if (b.isConnected) { delete b.dataset.sure; b.lastChild.textContent = 'Xóa ảnh đã lưu'; } }, 3000); return; }
    delete b.dataset.sure; b.lastChild.textContent = 'Xóa ảnh đã lưu';
    const r = await window.rsi.clearCache(); imgCache.clear(); msg(r.ok ? 'Đã xóa ảnh trong máy.' : r.message, r.ok); fillStats();
  };
  $('#autoSync').onchange = async e => { await window.rsi.setSettings({ autoSync: e.target.checked }); };
  $('#autoBackup').onchange = async e => {
    const st = await window.rsi.getStats();
    if (e.target.checked && !st.backupDir) { e.target.checked = false; msg('Hãy chọn thư mục sao lưu trước.', false); return; }
    await window.rsi.setSettings({ autoBackup: e.target.checked });
  };
  $('#bkDays').onclick = async e => { const b = e.target.closest('button'); if (!b) return; await window.rsi.setSettings({ backupDays: +b.dataset.d }); fillStats(); };
  $('#bkChoose').onclick = async () => { const r = await window.rsi.chooseBackupDir(); if (r.ok) { msg('Đã chọn thư mục sao lưu.', true); fillStats(); } else if (!r.canceled) msg(r.message, false); };
  $('#bkOpen').onclick = () => window.rsi.openBackupDir();
  const busy = async (btn, label, fn) => { const keep = btn.innerHTML; btn.disabled = true; btn.lastChild.textContent = label; try { return await fn(); } finally { btn.disabled = false; btn.innerHTML = keep; } };
  $('#bkRun').onclick = e => busy(e.currentTarget, 'Đang sao lưu…', async () => {
    const r = await window.rsi.runBackup();
    msg(r.ok ? `Đã sao lưu: ${r.slips} phiếu, ${r.imgs} ảnh${r.missing ? `, thiếu ${r.missing} ảnh` : ''}.` : r.message, r.ok); fillStats();
  });
  $('#bkList').onclick = async e => {
    const b = e.target.closest('button[data-n]'); if (!b) return;
    if (!b.dataset.sure) { b.dataset.sure = '1'; b.classList.add('sure'); setTimeout(() => { if (b.isConnected) { delete b.dataset.sure; b.classList.remove('sure'); } }, 3000); return; }
    const r = await window.rsi.deleteBackup(b.dataset.n); msg(r.ok ? 'Đã xóa bản sao lưu.' : r.message, r.ok); fillStats();
  };
  $('#exportZip').onclick = e => busy(e.currentTarget, 'Đang xuất…', async () => {
    const r = await window.rsi.exportZip();
    if (r.canceled) return; msg(r.ok ? `Đã xuất ${r.slips} phiếu, ${r.imgs} ảnh${r.missing ? `, thiếu ${r.missing} ảnh` : ''}.` : r.message, r.ok); fillStats();
  });
  $('#importFile').onclick = e => busy(e.currentTarget, 'Đang khôi phục…', async () => {
    const r = await window.rsi.importFile();
    if (r.canceled) return;
    if (r.ok) { slips = await window.rsi.load(); refreshAll(); }
    msg(r.ok ? `Đã khôi phục ${r.count} phiếu, ${r.images} ảnh.` : r.message, r.ok); fillStats();
  });
  $('#clearRestored').onclick = async e => {
    const b = e.currentTarget;
    if (!b.dataset.sure) { b.dataset.sure = '1'; b.lastChild.textContent = 'Bấm lần nữa để xóa'; setTimeout(() => { if (b.isConnected) { delete b.dataset.sure; b.lastChild.textContent = 'Xóa dữ liệu đã khôi phục'; } }, 3000); return; }
    delete b.dataset.sure; b.lastChild.textContent = 'Xóa dữ liệu đã khôi phục';
    const r = await window.rsi.clearRestored(); slips = await window.rsi.load(); refreshAll(); msg(r.ok ? 'Đã xóa dữ liệu khôi phục.' : r.message, r.ok); fillStats();
  };
  $('#logToggle').onclick = () => { const o = $('#logBox').classList.toggle('hidden'); $('#logToggle').classList.toggle('open', !o); };
  $('#logChips').onclick = e => { const b = e.target.closest('.chip'); if (!b) return; logFilter = b.dataset.k; renderLog(); };
  $('#clearLog').onclick = async e => {
    const b = e.currentTarget;
    if (!b.dataset.sure) { b.dataset.sure = '1'; b.lastChild.textContent = 'Bấm lần nữa để xóa'; setTimeout(() => { if (b.isConnected) { delete b.dataset.sure; b.lastChild.textContent = 'Xóa nhật ký'; } }, 3000); return; }
    delete b.dataset.sure; b.lastChild.textContent = 'Xóa nhật ký'; await window.rsi.clearLog(); loadLog();
  };
  $('#copyMail').onclick = async e => { try { await navigator.clipboard.writeText('quocdai.net@gmail.com'); const t = e.currentTarget.lastChild; t.textContent = 'Đã sao chép'; setTimeout(() => { t.textContent = 'quocdai.net@gmail.com'; }, 1800); } catch {} };
  window.rsi.onProgress?.(p => {
    $('#taskBar').classList.remove('hidden'); $('#taskText').textContent = `${p.title} ${p.done}/${p.total}`;
    $('#taskFill').style.width = (p.total ? Math.round(p.done / p.total * 100) : 100) + '%';
    if (p.done >= p.total) setTimeout(() => $('#taskBar').classList.add('hidden'), 700);
  });
  $('#syncNow').onclick = async () => { await sync(); fillStats(); };
  $('#openFolder').onclick = () => window.rsi.openDataFolder();
})();
