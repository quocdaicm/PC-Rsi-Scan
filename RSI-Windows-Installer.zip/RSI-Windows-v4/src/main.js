const { app, BrowserWindow, ipcMain, dialog, shell } = require('electron');
const path = require('path');
const fs = require('fs');
const https = require('https');
const crypto = require('crypto');
const archive = require('./archive');

let win;
const userDir = app.getPath('userData');
const storeFile = path.join(userDir, 'settings.json');
const cacheFile = path.join(userDir, 'slips.json');

function readJSON(file, fallback) { try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return fallback; } }
function writeJSON(file, value) { fs.mkdirSync(path.dirname(file), { recursive: true }); fs.writeFileSync(file, JSON.stringify(value, null, 2), 'utf8'); }
const restoredDir = path.join(userDir, 'restored');
const restoredFile = path.join(userDir, 'restored.json');
const activityFile = path.join(userDir, 'activity.json');
function getSettings() { return { manifestUrl: '', lastSync: null, dataVersion: '', autoSync: true, autoBackup: false, backupDir: '', backupDays: 7, lastBackup: null, ...readJSON(storeFile, {}) }; }
// Nhật ký thao tác (tối đa 500 dòng, mới nhất ở đầu)
function logAct(kind, rsi, detail = '') {
  const list = readJSON(activityFile, []); const arr = Array.isArray(list) ? list : [];
  const f = arr[0]; if (kind === 'failed' && f && f.kind === 'failed' && f.detail === detail) return;
  arr.unshift({ id: crypto.randomUUID(), date: new Date().toISOString(), kind, rsi: rsi || '', detail });
  try { writeJSON(activityFile, arr.slice(0, 500)); } catch {}
}

const imgDir = path.join(userDir, 'images');
// Ảnh: nhận ID file Drive hoặc URL https -> link tải trực tiếp
function imgSource(src) {
  const v = String(src || '').trim();
  if (v.startsWith('local:')) return v;
  if (/^https:\/\//i.test(v)) return v;
  if (/^[\w-]{10,}$/.test(v)) return `https://drive.google.com/uc?export=download&id=${v}`;
  return '';
}
const imgCachePath = url => path.join(imgDir, crypto.createHash('sha1').update(url).digest('hex') + '.bin');
function mimeOf(buf) {
  if (buf[0] === 0xff && buf[1] === 0xd8) return { mime: 'image/jpeg', ext: 'jpg' };
  if (buf[0] === 0x89 && buf[1] === 0x50) return { mime: 'image/png', ext: 'png' };
  if (buf.slice(0, 4).toString() === 'RIFF' && buf.slice(8, 12).toString() === 'WEBP') return { mime: 'image/webp', ext: 'webp' };
  if (buf.slice(0, 3).toString() === 'GIF') return { mime: 'image/gif', ext: 'gif' };
  return null;
}
function fetchBuffer(url, redirects = 0) {
  return new Promise((resolve, reject) => {
    if (!/^https:\/\//i.test(url)) return reject(new Error('Chỉ hỗ trợ URL HTTPS.'));
    if (redirects > 6) return reject(new Error('Quá nhiều chuyển hướng.'));
    https.get(url, { headers: { 'User-Agent': 'RSI-Windows/3.5', Accept: 'image/*,*/*' } }, res => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        res.resume();
        return fetchBuffer(new URL(res.headers.location, url).toString(), redirects + 1).then(resolve, reject);
      }
      if (res.statusCode !== 200) { res.resume(); return reject(new Error(`HTTP ${res.statusCode}`)); }
      const chunks = []; let size = 0;
      res.on('data', c => { size += c.length; if (size > 40e6) return res.destroy(new Error('Ảnh quá lớn.')); chunks.push(c); });
      res.on('end', () => resolve(Buffer.concat(chunks)));
      res.on('error', reject);
    }).on('error', reject).setTimeout(30000, function () { this.destroy(new Error('Hết thời gian chờ, kiểm tra mạng.')); });
  });
}
// Tải ảnh về cache trên máy (lần sau xem không cần mạng). Trả về { file, mime, ext }
async function ensureImage(src) {
  const url = imgSource(src); if (!url) throw new Error('Ảnh chưa có trên Drive.');
  if (url.startsWith('local:')) {
    const f = path.resolve(url.slice(6));
    if (!f.startsWith(path.resolve(restoredDir) + path.sep)) throw new Error('Đường dẫn ảnh không hợp lệ.');
    const buf = fs.readFileSync(f), mm = mimeOf(buf); if (!mm) throw new Error('File ảnh hỏng.');
    return { file: f, buf, ...mm };
  }
  const f = imgCachePath(url);
  let buf = null;
  try { buf = fs.readFileSync(f); } catch {}
  if (!buf || !buf.length || !mimeOf(buf)) {
    buf = await fetchBuffer(url);
    if (!mimeOf(buf)) throw new Error('Drive không trả về ảnh. Kiểm tra thư mục RSIScan đã chia sẻ "Bất kỳ ai có liên kết".');
    fs.mkdirSync(imgDir, { recursive: true }); fs.writeFileSync(f, buf);
  }
  return { file: f, buf, ...mimeOf(buf) };
}
const safeName = n => String(n || 'anh').replace(/[\\/:*?"<>|]+/g, '_').trim() || 'anh';

const configFile = path.join(__dirname, '..', 'data', 'config.json');
// Nhận link chia sẻ Drive, link uc?id=..., hoặc chỉ ID file -> link tải trực tiếp
function toDownloadUrl(input) {
  const v = String(input || '').trim(); if (!v) return '';
  const m = v.match(/\/file\/d\/([\w-]{10,})/) || v.match(/[?&]id=([\w-]{10,})/);
  if (m) return `https://drive.google.com/uc?export=download&id=${m[1]}`;
  if (/^[\w-]{20,}$/.test(v)) return `https://drive.google.com/uc?export=download&id=${v}`;
  return v;
}
// Ưu tiên cấu hình admin đổi trong Cài đặt; không có thì dùng data/config.json cài sẵn trong bộ cài
function effectiveUrl() { const s = getSettings(); return toDownloadUrl(s.manifestUrl || readJSON(configFile, {}).manifestUrl); }

function fetchText(url, redirects = 0) {
  return new Promise((resolve, reject) => {
    if (!/^https:\/\//i.test(url)) return reject(new Error('Chỉ hỗ trợ URL HTTPS.'));
    if (redirects > 5) return reject(new Error('Quá nhiều chuyển hướng.'));
    https.get(url, { headers: { 'User-Agent': 'RSI-Windows/3.1', Accept: 'application/json,text/plain,*/*' } }, res => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        const next = new URL(res.headers.location, url).toString();
        return fetchText(next, redirects + 1).then(resolve, reject);
      }
      if (res.statusCode !== 200) return reject(new Error(`HTTP ${res.statusCode}`));
      let data = ''; res.setEncoding('utf8');
      res.on('data', c => data += c); res.on('end', () => resolve(data));
    }).on('error', reject).setTimeout(20000, function () { this.destroy(new Error('Hết thời gian chờ, kiểm tra mạng.')); });
  });
}
function normalizeSlip(s) {
  return {
    id: s.id || crypto.randomUUID(), rsiNo: s.rsiNo || '', requestDate: s.requestDate || '', project: s.project || '', remark: s.remark || '',
    items: Array.isArray(s.items) ? s.items.map(i => ({ id:i.id||crypto.randomUUID(), packageNo:i.packageNo||'', desc:i.desc||'', tag:i.tag||'', unit:i.unit||'', qty:i.qty||'', actualQty:i.actualQty??'' })) : [],
    pages: Array.isArray(s.pages) ? s.pages : [], createdAt: s.createdAt ?? '',
    driveFolderID: s.driveFolderID || '', driveJSONID: s.driveJSONID || '', driveImages: s.driveImages || {}, driveNames: s.driveNames || {}, localImages: s.localImages || {},
    receivedBy: s.receivedBy || '', receivedDate: s.receivedDate || '', requestedBy: s.requestedBy || '', checkedBy: s.checkedBy || '', confirmedBy: s.confirmedBy || '', approvedBy: s.approvedBy || ''
  };
}
function loadData() {
  const local = readJSON(cacheFile, null);
  const base = Array.isArray(local) ? local.map(normalizeSlip) : readJSON(path.join(__dirname, '..', 'data', 'slips.json'), []).map(normalizeSlip);
  const rest = readJSON(restoredFile, []);
  if (Array.isArray(rest) && rest.length) {
    const ids = new Set(base.map(x => String(x.id)));
    for (const r of rest.map(normalizeSlip)) if (!ids.has(String(r.id))) base.push(r);
  }
  return base;
}
function createWindow() {
  win = new BrowserWindow({ width: 1360, height: 900, minWidth: 980, minHeight: 680, backgroundColor: '#f4f7f5', title: 'RSI', webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false, sandbox: true } });
  win.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));   // không mở cửa sổ phụ
  win.loadFile(path.join(__dirname, 'index.html'));
}
app.whenReady().then(() => { createWindow(); app.on('activate', () => { if (!BrowserWindow.getAllWindows().length) createWindow(); }); });
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });

ipcMain.handle('data:load', () => loadData());
ipcMain.handle('settings:get', () => {
  const s = getSettings();
  return { manifestUrl: s.manifestUrl, hasSource: !!effectiveUrl(), lastSync: s.lastSync, dataVersion: s.dataVersion, autoSync: s.autoSync !== false };
});
ipcMain.handle('settings:set', (_, patch) => {
  const s=getSettings();
  if (patch.manifestUrl !== undefined) { s.manifestUrl=String(patch.manifestUrl||'').trim(); logAct('config', '', s.manifestUrl ? 'Đổi link nguồn dữ liệu' : 'Dùng lại nguồn cài sẵn'); }
  if (patch.autoSync !== undefined) s.autoSync = !!patch.autoSync;
  if (patch.autoBackup !== undefined) s.autoBackup = !!patch.autoBackup;
  if (patch.backupDays !== undefined) s.backupDays = [1, 7, 30].includes(+patch.backupDays) ? +patch.backupDays : 7;
  writeJSON(storeFile,s); return {ok:true};
});
function dirStats(dir) { let size = 0, count = 0; try { for (const f of fs.readdirSync(dir)) { try { const st = fs.statSync(path.join(dir, f)); if (st.isFile()) { size += st.size; count++; } } catch {} } } catch {} return { size, count }; }
ipcMain.handle('stats:get', () => {
  const s = getSettings(), slips = loadData(), im = dirStats(imgDir), rest = readJSON(restoredFile, []);
  return { ok:true, slips: slips.length, pages: slips.reduce((n, x) => n + x.pages.length, 0), cacheBytes: im.size, cacheCount: im.count, lastSync: s.lastSync, dataVersion: s.dataVersion, usingBuiltIn: !s.manifestUrl,
    appVersion: app.getVersion ? app.getVersion() : '', autoSync: s.autoSync !== false, autoBackup: !!s.autoBackup, backupDir: s.backupDir || '', backupDays: s.backupDays || 7, lastBackup: s.lastBackup, restored: Array.isArray(rest) ? rest.length : 0 };
});
ipcMain.handle('cache:clear', () => {
  try { for (const f of fs.readdirSync(imgDir)) fs.rmSync(path.join(imgDir, f), { force: true }); } catch {}
  logAct('config', '', 'Xóa ảnh đã lưu trong máy');
  return { ok:true };
});
function logSyncDiff(prev, next) {
  if (!Array.isArray(prev)) { if (next.length) logAct('created', '', `Lần đồng bộ đầu tiên: ${next.length} phiếu`); return; }
  const before = new Map(prev.map(normalizeSlip).map(x => [String(x.id), x])), seen = new Set(); let created = 0;
  const people = x => [x.receivedBy, x.receivedDate, x.requestedBy, x.checkedBy, x.confirmedBy, x.approvedBy].join('|');
  const itemSig = x => JSON.stringify(x.items.map(i => [i.packageNo, i.desc, i.tag, i.unit, i.qty, i.actualQty]));
  for (const n of next) {
    const k = String(n.id), o = before.get(k); seen.add(k);
    if (!o) { created++; if (created <= 30) logAct('created', n.rsiNo, `${n.items.length} kiện · ${n.pages.length} ảnh`); continue; }
    const ch = [];
    if (o.rsiNo !== n.rsiNo) ch.push(`Số RSI: ${o.rsiNo || 'trống'} → ${n.rsiNo || 'trống'}`);
    if (o.requestDate !== n.requestDate) ch.push(`Ngày: ${o.requestDate || 'trống'} → ${n.requestDate || 'trống'}`);
    if (o.project !== n.project) ch.push('Dự án');
    if (o.remark !== n.remark) ch.push('Ghi chú');
    if (itemSig(o) !== itemSig(n)) ch.push(`Kiện hàng (${o.items.length} → ${n.items.length})`);
    if (o.pages.length !== n.pages.length) ch.push(`Ảnh (${o.pages.length} → ${n.pages.length})`);
    if (people(o) !== people(n)) ch.push('Ký nhận');
    if (ch.length) logAct('edited', n.rsiNo, ch.join('; '));
  }
  if (created > 30) logAct('created', '', `và ${created - 30} phiếu mới khác`);
  for (const [k, o] of before) if (!seen.has(k)) logAct('deleted', o.rsiNo, 'Phiếu không còn trên Drive');
}
ipcMain.handle('sync:run', async () => {
  const s=getSettings(); const url=effectiveUrl(); if (!url) return {ok:false, code:'NO_URL', message:'Chưa có nguồn dữ liệu (data/config.json).'};
  try {
    const text=await fetchText(url);
    if (/^\s*</.test(text)) throw new Error('Drive trả về trang web, không phải JSON. Kiểm tra file index.json đã chia sẻ "Bất kỳ ai có liên kết".');
    const payload=JSON.parse(text);
    const data=Array.isArray(payload) ? payload : payload.slips;
    if (!Array.isArray(data)) throw new Error('Nguồn dữ liệu phải là mảng JSON hoặc object có trường slips.');
    const normalized=data.map(normalizeSlip);
    logSyncDiff(readJSON(cacheFile, null), normalized);
    writeJSON(cacheFile, normalized);
    s.lastSync=new Date().toISOString(); s.dataVersion=String(payload.version ?? s.lastSync); writeJSON(storeFile,s);
    logAct('synced', '', `${normalized.length} phiếu`);
    return {ok:true,count:normalized.length,lastSync:s.lastSync,dataVersion:s.dataVersion};
  } catch(e) { logAct('failed', '', e.message); return {ok:false,message:e.message}; }
});
ipcMain.handle('app:openDataFolder', () => {fs.mkdirSync(imgDir,{recursive:true}); shell.openPath(imgDir); return {ok:true}; });
ipcMain.handle('app:about', () => dialog.showMessageBox(win,{type:'info',title:'RSI Windows',message:'RSI Windows 3.11',detail:'Tra cứu RSI và tự đồng bộ index.json + ảnh từ Google Drive công khai.'}));

ipcMain.handle('img:get', async (_, src) => {
  try { const im = await ensureImage(src); return { ok: true, dataUrl: `data:${im.mime};base64,${im.buf.toString('base64')}`, ext: im.ext }; }
  catch (e) { return { ok: false, message: e.message }; }
});
ipcMain.handle('img:save', async (_, src, name) => {
  try {
    const im = await ensureImage(src);
    const r = await dialog.showSaveDialog(win, { defaultPath: `${safeName(name)}.${im.ext}`, filters: [{ name: 'Ảnh', extensions: [im.ext] }] });
    if (r.canceled || !r.filePath) return { ok: false, canceled: true };
    fs.copyFileSync(im.file, r.filePath); return { ok: true, path: r.filePath };
  } catch (e) { return { ok: false, message: e.message }; }
});
ipcMain.handle('img:saveAll', async (_, items) => {
  try {
    const r = await dialog.showOpenDialog(win, { title: 'Chọn thư mục lưu ảnh', properties: ['openDirectory', 'createDirectory'] });
    if (r.canceled || !r.filePaths[0]) return { ok: false, canceled: true };
    let n = 0;
    for (const it of (Array.isArray(items) ? items : [])) {
      try { const im = await ensureImage(it.src); fs.copyFileSync(im.file, path.join(r.filePaths[0], `${safeName(it.name)}.${im.ext}`)); n++; } catch {}
    }
    return { ok: n > 0, count: n, dir: r.filePaths[0], message: n ? '' : 'Không tải được ảnh nào.' };
  } catch (e) { return { ok: false, message: e.message }; }
});

// ---------- Xuất toàn bộ (.zip), sao lưu ra thư mục, khôi phục ----------
const toTime = v => (typeof v === 'number' ? (v + 978307200) * 1000 : (Date.parse(v) || 0));
const safeRsi = x => (x.rsiNo || 'phieu').replace(/[\\/:*?"<>|]+/g, '-');
function pageSrc(sl, name) {
  const li = (sl.localImages || {})[name]; if (li) return 'local:' + li;
  if (/^https?:\/\//i.test(String(name || ''))) return name;
  return (sl.driveImages || {})[name] || '';
}
function sendProgress(title, done, total) { try { if (win && !win.isDestroyed()) win.webContents.send('task:progress', { title, done, total }); } catch {} }
const CSV_HEAD = ['Số RSI', 'Ngày yêu cầu', 'Dự án', 'Người nhận', 'Ngày nhận', 'Yêu cầu (Requested By)', 'Kiểm tra (Checked By)', 'Xác nhận (Confirmed By)', 'Duyệt (Approved By)', 'Ghi chú', 'Package No', 'Mô tả hàng', 'Tag/Serial', 'Đơn vị', 'Số lượng', 'SL thực nhận', 'File ảnh'];
const csvEsc = v => '"' + String(v ?? '').replace(/"/g, '""') + '"';
// Gồm slips.csv (mở bằng Excel), slips.json và thư mục Anh/ chứa ảnh đặt tên theo số RSI (giống bản xuất trên iPhone)
async function buildExport(zipPath, title) {
  const slips = loadData().sort((a, b) => toTime(a.createdAt) - toTime(b.createdAt));
  const total = slips.reduce((n, x) => n + x.pages.length, 0); let done = 0, imgs = 0, missing = 0;
  const zw = new archive.ZipWriter(zipPath), rows = [CSV_HEAD.map(csvEsc).join(',')], used = new Set();
  try {
    for (const sl of slips) {
      const safe = safeRsi(sl), files = [];
      for (let i = 0; i < sl.pages.length; i++) {
        try {
          const im = await ensureImage(pageSrc(sl, sl.pages[i]));
          let fn = `${safe}_${i + 1}.${im.ext}`; for (let k = 2; used.has(fn.toLowerCase()); k++) fn = `${safe}_${i + 1}_${k}.${im.ext}`;
          used.add(fn.toLowerCase()); zw.add('Anh/' + fn, im.buf); files.push(fn); imgs++;
        } catch { missing++; }
        sendProgress(title, ++done, total);
      }
      const head = [sl.rsiNo, sl.requestDate, sl.project, sl.receivedBy, sl.receivedDate, sl.requestedBy, sl.checkedBy, sl.confirmedBy, sl.approvedBy, sl.remark];
      for (const it of (sl.items.length ? sl.items : [{}])) rows.push([...head, it.packageNo, it.desc, it.tag, it.unit, it.qty, it.actualQty, files.join('; ')].map(csvEsc).join(','));
    }
    zw.add('slips.csv', Buffer.from('\ufeff' + rows.join('\n') + '\n', 'utf8'), { deflate: true });
    zw.add('slips.json', Buffer.from(JSON.stringify(slips, null, 2), 'utf8'), { deflate: true });
  } finally { zw.close(); }
  return { slips: slips.length, imgs, missing };
}
const stamp = () => { const d = new Date(), p = n => String(n).padStart(2, '0'); return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}_${p(d.getHours())}${p(d.getMinutes())}`; };
ipcMain.handle('export:zip', async () => {
  try {
    const r = await dialog.showSaveDialog(win, { defaultPath: `RSI-export-${stamp()}.zip`, filters: [{ name: 'Zip', extensions: ['zip'] }] });
    if (r.canceled || !r.filePath) return { ok:false, canceled:true };
    const res = await buildExport(r.filePath, 'Đang xuất file zip');
    logAct('export', '', `${res.slips} phiếu, ${res.imgs} ảnh${res.missing ? `, thiếu ${res.missing} ảnh` : ''}`);
    return { ok:true, path:r.filePath, ...res };
  } catch (e) { logAct('failed', '', 'Xuất zip: ' + e.message); return { ok:false, message:e.message }; }
});
const BK = /^RSI-backup-.*\.zip$/;
async function runBackup() {
  const s = getSettings(); if (!s.backupDir) throw new Error('Chưa chọn thư mục sao lưu.');
  fs.mkdirSync(s.backupDir, { recursive: true });
  const name = `RSI-backup-${stamp()}.zip`, file = path.join(s.backupDir, name);
  const res = await buildExport(file, 'Đang sao lưu');
  const olds = fs.readdirSync(s.backupDir).filter(f => BK.test(f)).map(f => ({ f, t: fs.statSync(path.join(s.backupDir, f)).mtimeMs })).sort((a, b) => b.t - a.t).slice(5);
  for (const o of olds) fs.rmSync(path.join(s.backupDir, o.f), { force: true });     // giữ 5 bản mới nhất
  const s2 = getSettings(); s2.lastBackup = new Date().toISOString(); writeJSON(storeFile, s2);
  logAct('backup', '', `${name}: ${res.slips} phiếu, ${res.imgs} ảnh`);
  return { name, ...res };
}
ipcMain.handle('backup:choose', async () => {
  const r = await dialog.showOpenDialog(win, { title: 'Chọn thư mục sao lưu', properties: ['openDirectory', 'createDirectory'] });
  if (r.canceled || !r.filePaths[0]) return { ok:false, canceled:true };
  const s = getSettings(); s.backupDir = r.filePaths[0]; writeJSON(storeFile, s); logAct('config', '', 'Chọn thư mục sao lưu');
  return { ok:true, dir:s.backupDir };
});
ipcMain.handle('backup:run', async () => {
  try { return { ok:true, ...(await runBackup()) }; } catch (e) { logAct('failed', '', 'Sao lưu: ' + e.message); return { ok:false, message:e.message }; }
});
ipcMain.handle('backup:list', () => {
  const d = getSettings().backupDir; if (!d) return { ok:true, files:[] };
  try { return { ok:true, files: fs.readdirSync(d).filter(f => BK.test(f)).map(f => { const st = fs.statSync(path.join(d, f)); return { name:f, size:st.size, time:st.mtime.toISOString() }; }).sort((a, b) => b.time.localeCompare(a.time)) }; } catch { return { ok:true, files:[] }; }
});
ipcMain.handle('backup:delete', (_, name) => {
  const d = getSettings().backupDir; if (!d || !BK.test(String(name)) || String(name).includes('/') || String(name).includes('\\')) return { ok:false, message:'Tên file không hợp lệ.' };
  try { fs.rmSync(path.join(d, name), { force: true }); logAct('config', '', 'Xóa bản sao lưu ' + name); return { ok:true }; } catch (e) { return { ok:false, message:e.message }; }
});
ipcMain.handle('backup:openDir', () => {const d = getSettings().backupDir; if (d) shell.openPath(d); return { ok:!!d }; });
// Khôi phục từ file zip đã xuất (hoặc file .json): dữ liệu được giữ riêng, đồng bộ không xóa
ipcMain.handle('import:file', async () => {
  try {
    const r = await dialog.showOpenDialog(win, { title: 'Chọn file zip đã xuất hoặc file .json', properties: ['openFile'], filters: [{ name: 'Zip hoặc JSON', extensions: ['zip', 'json'] }] });
    if (r.canceled || !r.filePaths[0]) return { ok:false, canceled:true };
    const file = r.filePaths[0]; let raw, images = new Map();
    if (/\.json$/i.test(file)) raw = JSON.parse(fs.readFileSync(file, 'utf8'));
    else {
      const entries = archive.readZip(file), js = entries.find(e => path.basename(e.name).toLowerCase() === 'slips.json');
      if (!js) throw new Error('Không thấy slips.json trong file zip.');
      raw = JSON.parse(js.read().toString('utf8'));
      for (const e of entries) if (/(^|\/)Anh\/[^/]+\.(jpe?g|png|webp)$/i.test(e.name)) images.set(path.basename(e.name).toLowerCase(), e);
    }
    const list = (Array.isArray(raw) ? raw : raw && raw.slips); if (!Array.isArray(list)) throw new Error('File không đúng định dạng phiếu.');
    fs.mkdirSync(restoredDir, { recursive: true });
    let imgCount = 0; const slips = list.map(normalizeSlip);
    for (const sl of slips) {
      const safe = safeRsi(sl).toLowerCase();
      sl.pages.forEach((pg, i) => {
        for (const ext of ['jpg', 'jpeg', 'png', 'webp']) {
          const e = images.get(`${safe}_${i + 1}.${ext}`); if (!e) continue;
          const out = path.join(restoredDir, `${crypto.createHash('sha1').update(String(sl.id)).digest('hex').slice(0, 10)}_${i + 1}.${ext}`);
          fs.writeFileSync(out, e.read()); sl.localImages[pg] = out; imgCount++; break;
        }
      });
    }
    const cur = readJSON(restoredFile, []), map = new Map((Array.isArray(cur) ? cur : []).map(x => [String(x.id), x]));
    for (const sl of slips) map.set(String(sl.id), sl);
    writeJSON(restoredFile, [...map.values()]);
    logAct('restore', '', `${slips.length} phiếu, ${imgCount} ảnh từ ${path.basename(file)}`);
    return { ok:true, count:slips.length, images:imgCount };
  } catch (e) { logAct('failed', '', 'Khôi phục: ' + e.message); return { ok:false, message:e.message }; }
});
ipcMain.handle('restore:clear', () => {
  try { fs.rmSync(restoredFile, { force: true }); fs.rmSync(restoredDir, { recursive: true, force: true }); logAct('config', '', 'Xóa dữ liệu đã khôi phục'); return { ok:true }; } catch (e) { return { ok:false, message:e.message }; }
});
ipcMain.handle('log:get', () => {const l = readJSON(activityFile, []); return { ok:true, entries: Array.isArray(l) ? l : [] }; });
ipcMain.handle('log:clear', () => {try { fs.rmSync(activityFile, { force: true }); } catch {} return { ok:true }; });

// Tự sao lưu khi mở app nếu đã đến hạn
function backupDue() {
  const s = getSettings(); if (!s.autoBackup || !s.backupDir) return false;
  return Date.now() - (Date.parse(s.lastBackup) || 0) >= (s.backupDays || 7) * 86400000 - 60000;
}
app.whenReady().then(() => setTimeout(() => { if (backupDue()) runBackup().catch(e => logAct('failed', '', 'Tự sao lưu: ' + e.message)); }, 10000));
