# RSI Windows

Bản Windows dành cho khách hàng tra cứu dữ liệu RSI. Ứng dụng đọc dữ liệu JSON HTTPS ở chế độ chỉ đọc, lưu cache trên PC và cho phép xem ảnh từ các URL HTTPS công khai.

## Chạy thử

```bash
npm install
npm start
```

## Build bộ cài Windows

```bash
npm run dist
```

Kết quả: `dist/RSI-Setup-3.11.0.exe`

## Dữ liệu

Xem `data/manifest.example.json`. Nguồn thật có thể là một JSON công khai trên Google Drive/hosting. Dạng khuyến nghị:

```json
{"version":"2026-10-08-01","slips":[...]}
```

Mỗi `pages` nên chứa URL HTTPS có thể xem/tải mà không cần đăng nhập Google. Nếu dùng Google Drive, đặt file/ảnh ở chế độ **Anyone with the link / Viewer** hoặc dùng một trang/hosting tạo URL ảnh công khai.

## Cài đặt

Không còn đăng nhập/mật khẩu. Mục **Cài đặt** mở sẵn: link nguồn dữ liệu, đồng bộ, ảnh đã lưu, nhật ký, sao lưu, xuất/khôi phục. Ảnh chỉ được tải lên từ app iPhone.

Khách hàng không có mật khẩu không thể thay đổi nguồn dữ liệu.

## GitHub Actions

Push project lên GitHub rồi vào **Actions → Build Windows EXE → Run workflow**. Artifact `RSI-Windows-Installer` chứa file setup.


## Đồng bộ Google Drive không cần đăng nhập khách
1. Trên Google Drive, chia sẻ thư mục gốc `RSIScan` thành **Bất kỳ ai có liên kết → Người xem**.
2. Trong thư mục `RSIScan`, file `index.json` do app iPhone tạo sẽ chứa danh sách phiếu và ID ảnh trên Drive.
3. Lấy link tải công khai của `index.json`, ví dụ `https://drive.google.com/uc?export=download&id=FILE_ID`.
4. Mở RSI Windows → Cài đặt → đăng nhập Admin → dán link → Lưu.
5. Khách hàng chỉ cần mở RSI.exe và bấm Đồng bộ; không cần tài khoản Google.

**Lưu ý:** đây là mô hình dữ liệu công khai. Chỉ dùng khi dữ liệu không nhạy cảm, đúng như yêu cầu hiện tại.


## Cài sẵn nguồn dữ liệu (khách không cần cài đặt hay đăng nhập)
Mở `data/config.json`, dán link chia sẻ của file `RSIScan/index.json` trên Google Drive (hoặc chỉ ID file) vào `manifestUrl`, rồi build. File phải để chế độ **Bất kỳ ai có liên kết → Người xem**, và thư mục `RSIScan` cũng chia sẻ như vậy để xem được ảnh.
Khách chỉ cần cài và mở app: app tự đồng bộ mỗi lần mở, mất mạng thì dùng dữ liệu đã lưu. Admin vẫn có thể đổi nguồn trong Cài đặt (ưu tiên hơn config.json).

## Cài đặt (chỉ admin, giống app iPhone)
Nguồn dữ liệu và tự đồng bộ, dung lượng ảnh đã lưu, nhật ký thao tác (tạo/sửa/xóa phiếu khi đồng bộ, đăng nhập, lỗi...), tự động sao lưu ra thư mục trên máy (hàng ngày/tuần/tháng, giữ 5 bản), xuất toàn bộ ảnh và thông tin ra file .zip (slips.csv, slips.json, thư mục Anh/), khôi phục từ file zip đã xuất, đổi mật khẩu.
Các mục chỉ có trên điện thoại (mức nén ảnh khi quét, đăng nhập Google, tải phiếu lên Drive) không có ở bản PC vì PC chỉ đọc dữ liệu.
