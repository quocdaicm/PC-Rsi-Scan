const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('rsi', {
  load: () => ipcRenderer.invoke('data:load'),
  getSettings: () => ipcRenderer.invoke('settings:get'),
  setupAdmin: p => ipcRenderer.invoke('admin:setup', p),
  loginAdmin: p => ipcRenderer.invoke('admin:login', p),
  logoutAdmin: t => ipcRenderer.invoke('admin:logout', t),
  setSettings: (t,p) => ipcRenderer.invoke('settings:set', t, p),
  sync: () => ipcRenderer.invoke('sync:run'),
  openDataFolder: t => ipcRenderer.invoke('app:openDataFolder', t),
  about: () => ipcRenderer.invoke('app:about')
});
