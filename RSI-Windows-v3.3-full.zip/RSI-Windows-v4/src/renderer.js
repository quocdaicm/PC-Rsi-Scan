'use strict';
// Logic tìm kiếm / ngày tháng / tổng hợp mã kiện được port từ bản iOS
// (Search.swift, MonthFilter.swift, Model.swift: SlipDate, History.swift).

let slips = [];
let adminToken = null;
let selectedMonth = null;      // null = tất cả; số = year*100+month
let monthInit = false;
let showSuggest = true;

const $ = s => document.querySelector(s);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

// ---------- Ảnh Drive ----------
function driveFileUrl(id, mode = 'view') { return id ? `https://drive.google.com/uc?export=${mode}&id=${encodeURIComponent(id)}` : ''; }
function pageUrl(s, name) { if (/^https?:\/\//i.test(String(name || ''))) return name; const id = (s.driveImages || {})[name]; return driveFileUrl(id, 'view'); }

// ---------- Fuzzy (giống Fuzzy trong Search.swift) ----------
const Fuzzy = {
  norm(s) { return String(s ?? '').normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/đ/gi, 'd').toLowerCase(); },
  words(s) { return Fuzzy.norm(s).split(/[^a-z0-9]+/).filter(Boolean); },
  lev(a, b) {
    if (!a.length) return b.length; if (!b.length) return a.length;
    let p = Array.from({ length: b.length + 1 }, (_, i) => i);
    for (let i = 1; i <= a.length; i++) {
      const c = [i];
      for (let j = 1; j <= b.length; j++) c[j] = Math.min(p[j] + 1, c[j - 1] + 1, p[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
      p = c;
    }
    return p[b.length];
  },
  maxDist(n) { return n >= 7 ? 2 : (n >= 4 ? 1 : 0); },
  isSubsequence(q, t) { let i = 0; for (const c of t) { if (c === q[i]) i++; if (i === q.length) return true; } return q.length === 0; },
  // 0 = không khớp; 110/100 chứa nguyên cụm; 85 chứa đủ các từ; 60 gần đúng; 40 rải rác (chỉ cho mã)
  score(query, text, subsequence = false) {
    const qw = Fuzzy.words(query), q = qw.join(''); if (!q) return 0;
    const tw = Fuzzy.words(text), t = tw.join(''); if (!t) return 0;
    if (t.includes(q)) return t.startsWith(q) ? 110 : 100;
    if (qw.length > 1 && qw.every(w => t.includes(w))) return 85;
    let allOK = true;
    for (const tok of qw) {
      if (t.includes(tok)) continue;
      const d = Fuzzy.maxDist(tok.length);
      if (d === 0 || /^\d+$/.test(tok)) { allOK = false; break; }   // số thì phải đúng
      const ok = tw.some(w => {
        if (Math.abs(w.length - tok.length) <= d && Fuzzy.lev(tok, w) <= d) return true;
        if (w.length > tok.length && Fuzzy.lev(tok, w.slice(0, tok.length)) <= d) return true;
        return false;
      });
      if (!ok) { allOK = false; break; }
    }
    if (allOK) return 60;
    if (subsequence && q.length >= 4 && Fuzzy.isSubsequence(q, t)) return 40;
    return 0;
  }
};

// ---------- Ngày (giống SlipDate + monthKey + slipsNewestFirst) ----------
const MONTHS = ['jan', 'feb', 'mar', 'apr', 'may', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec'];
function mkDate(y, m, d) {
  if (y < 100) y += 2000;
  if (m < 1 || m > 12 || d < 1 || d > 31) return null;
  const dt = new Date(y, m - 1, d);
  return dt.getMonth() === m - 1 && dt.getDate() === d ? dt : null;
}
function parseSlipDate(str) {
  const t = String(str ?? '').trim(); if (!t) return null;
  let m;
  if ((m = t.match(/^(\d{4})-(\d{1,2})-(\d{1,2})$/))) return mkDate(+m[1], +m[2], +m[3]);
  if ((m = t.match(/^(\d{1,2})[-\s]([A-Za-z]{3,9})[-\s,]*(\d{2}|\d{4})$/))) {
    const mi = MONTHS.indexOf(m[2].slice(0, 3).toLowerCase());
    return mi >= 0 ? mkDate(+m[3], mi + 1, +m[1]) : null;
  }
  if ((m = t.match(/^(\d{1,2})[\/.\-](\d{1,2})[\/.\-](\d{2}|\d{4})$/))) return mkDate(+m[3], +m[2], +m[1]);   // ngày trước tháng
  return null;
}
function createdDate(s) {
  const c = s.createdAt;
  if (typeof c === 'number') return new Date((c + 978307200) * 1000);      // Swift Date: giây từ 2001-01-01
  if (typeof c === 'string' && c) { const d = new Date(c); if (!isNaN(d)) return d; }
  return new Date(0);
}
const slipDate = s => parseSlipDate(s.requestDate) || createdDate(s);
const monthId = s => { const d = slipDate(s); return d.getFullYear() * 100 + d.getMonth() + 1; };
const monthShort = id => `${id % 100}/${Math.floor(id / 100)}`;
const monthTitle = id => `Tháng ${id % 100}/${Math.floor(id / 100)}`;
function nowMonthId() { const d = new Date(); return d.getFullYear() * 100 + d.getMonth() + 1; }
function slipsNewestFirst(list = slips) {
  return list.map(s => [s, slipDate(s)]).sort((a, b) => (a[1] - b[1] !== 0 ? b[1] - a[1] : createdDate(b[0]) - createdDate(a[0]))).map(x => x[0]);
}
function monthCounts() {
  const c = new Map([[nowMonthId(), 0]]);
  for (const s of slips) { const k = monthId(s); c.set(k, (c.get(k) || 0) + 1); }
  return [...c.entries()].sort((a, b) => b[0] - a[0]);
}

// ---------- Tìm kiếm (giống Store.hits trong Search.swift) ----------
function itemScore(q, it) {
  return Math.max(Fuzzy.score(q, it.packageNo, true), Fuzzy.score(q, it.desc), Fuzzy.score(q, it.tag));
}
function hits(q) {
  const t = q.trim(), base = slipsNewestFirst();
  if (!t) return base.map(s => ({ s, items: [], score: 0 }));
  const out = [];
  base.forEach((s, idx) => {
    const rsiScore = Fuzzy.score(t, s.rsiNo, true);
    let best = rsiScore;
    for (const f of [s.requestDate, s.project, s.remark]) {
      const sc = Fuzzy.score(t, f); if (sc >= 85) best = Math.max(best, sc - 20);
    }
    let matched = [];
    for (const it of s.items) { const sc = itemScore(t, it); if (sc > 0) matched.push([it, sc]); }
    matched.sort((a, b) => b[1] - a[1]);
    if (matched.length) {
      best = Math.max(best, matched[0][1]);
      const minScore = rsiScore >= 100 ? 85 : Math.min(matched[0][1], 85);
      matched = matched.filter(x => x[1] >= minScore);
    }
    if (best > 0) out.push({ s, items: matched.map(x => x[0]), score: best, idx });
  });
  return out.sort((a, b) => (a.score !== b.score ? b.score - a.score : a.idx - b.idx));
}
const onlyWithMatchedItems = hs => (hs.some(h => h.items.length) ? hs.filter(h => h.items.length) : hs);

// ---------- Lịch sử xuất / tổng hợp mã kiện (History.swift) ----------
const key = x => String(x ?? '').trim().toUpperCase();
const sameGoods = (a, b) => !!key(a.packageNo) && key(a.packageNo) === key(b.packageNo) && key(a.tag) === key(b.tag);
const qtyValue = it => { const n = Number(String(it.qty ?? '').trim().replace(',', '.')); return String(it.qty ?? '').trim() !== '' && isFinite(n) ? n : null; };
const formatQty = v => (Number.isInteger(v) ? String(v) : v.toFixed(2));
function totalsText(recs) {
  const sums = new Map();
  for (const r of recs) { const v = qtyValue(r.item); if (v === null) continue; const u = key(r.item.unit); sums.set(u, (sums.get(u) || 0) + v); }
  return sums.size ? [...sums].map(([u, v]) => `${formatQty(v)} ${u}`.trim()).join(', ') : '-';
}
function historyFor(item) {
  const out = [];
  for (const s of slipsNewestFirst()) for (const x of s.items) if (sameGoods(x, item)) out.push({ slip: s, item: x });
  return out;
}
function packageSummaries(q, hs) {
  const t = q.trim(); if (!t) return [];
  const qKey = Fuzzy.words(t).join('');
  const order = [], groups = new Map();
  for (const h of hs) for (const it of h.items) {
    if (Fuzzy.score(t, it.packageNo) < 85) continue;
    const k = Fuzzy.words(it.packageNo).join('');
    if (!groups.has(k)) { order.push(k); groups.set(k, { item: it, recs: [] }); }
    groups.get(k).recs.push({ slip: h.s, item: it });
  }
  if (groups.has(qKey)) {       // mã đọc sai do OCR gộp vào đúng mã đang tìm
    for (const k of [...order]) if (k !== qKey && k.includes(qKey)) { groups.get(qKey).recs.push(...groups.get(k).recs); groups.delete(k); }
  }
  return order.filter(k => groups.has(k)).map(k => groups.get(k));
}

// ---------- Gợi ý (Store.suggestions) ----------
function suggestions(q, limit = 6) {
  const t = q.trim(); if (!t) return [];
  const seen = new Set(), list = [];
  for (const s of slipsNewestFirst()) {
    const r = Fuzzy.score(t, s.rsiNo, true);
    if (r > 0 && !seen.has('r-' + key(s.rsiNo))) {
      seen.add('r-' + key(s.rsiNo));
      list.push({ kind: 'rsi', text: s.rsiNo, sub: `${s.items.length} kiện` + (s.requestDate ? ` · ${s.requestDate}` : ''), score: r + 8 });
    }
    for (const it of s.items) {
      const p = Fuzzy.score(t, it.packageNo, true), pk = `p-${s.id}-${key(it.packageNo)}`;
      if (p > 0 && !seen.has(pk)) { seen.add(pk); list.push({ kind: 'package', text: it.packageNo, sub: `trong ${s.rsiNo}` + (it.qty ? ` · ${it.qty} ${it.unit}` : ''), score: p + 4 }); }
      if (it.desc) {
        const d = Fuzzy.score(t, it.desc), dk = `d-${s.id}-${key(it.desc)}`;
        if (d > 0 && !seen.has(dk)) { seen.add(dk); list.push({ kind: 'desc', text: it.desc, sub: `trong ${s.rsiNo} · ${it.packageNo}`, score: d }); }
      }
    }
  }
  return list.map((x, i) => [x, i]).sort((a, b) => (a[0].score !== b[0].score ? b[0].score - a[0].score : a[1] - b[1])).slice(0, limit).map(x => x[0]);
}

// ---------- Tô sáng (highlighted trong Search.swift) ----------
function highlight(text, q) {
  const s = String(text ?? ''), t = q.trim();
  if (!t) return esc(s);
  const fold = c => c.normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/đ/gi, 'd').toLowerCase();
  const chars = [...s], folded = chars.map(fold);
  if (folded.some(f => f.length !== 1)) return esc(s);
  const i = folded.join('').indexOf(fold(t));
  if (i < 0 || fold(t).length !== [...t].length) return esc(s);
  const n = [...t].length;
  return esc(chars.slice(0, i).join('')) + '<mark>' + esc(chars.slice(i, i + n).join('')) + '</mark>' + esc(chars.slice(i + n).join(''));
}

// ---------- Giao diện ----------
function matchRows(items, q) {
  if (!items.length) return '';
  return `<div class="items"><div class="itemsTitle">Kiện hàng khớp</div>${items.slice(0, 3).map(i => `<div class="item"><span><b>${highlight(i.packageNo, q)}</b><br>${highlight(i.desc, q)}</span><b>${esc(i.qty)} ${esc(i.unit)}${i.actualQty ? ` · nhận ${esc(i.actualQty)}` : ''}</b></div>`).join('')}${items.length > 3 ? `<div class="muted">+${items.length - 3} kiện khớp khác</div>` : ''}</div>`;
}
function card(s, items = [], q = '') {
  return `<div class="card" data-id="${esc(s.id)}"><div class="rowtop"><div><div class="rsi">${highlight(s.rsiNo || 'Chưa có số RSI', q)}</div><div class="muted">${esc(s.requestDate || '-')}${s.project ? ' · ' + esc(s.project) : ''}</div></div><div class="countPill">${(s.items || []).length} kiện · ${(s.pages || []).length} ảnh</div></div>${s.remark ? `<div class="remark">${esc(s.remark)}</div>` : ''}${items.length ? matchRows(items, q) : `<div class="tags">${(s.items || []).slice(0, 6).map(i => `<span class="tag">${esc(i.packageNo || i.tag || i.desc)}</span>`).join('')}</div>`}</div>`;
}
function summaryCard(sm, idx) {
  const it = sm.item;
  return `<div class="sumCard" data-sum="${idx}"><div class="sumPkg">${esc(it.packageNo)}</div>${it.desc ? `<div class="sumDesc">${esc(it.desc)}</div>` : ''}${it.tag ? `<span class="sumTag">${esc(it.tag)}</span>` : ''}<div class="sumLine">Đã xuất ${sm.recs.length} lần · tổng ${esc(totalsText(sm.recs))} <span>›</span></div></div>`;
}
let lastSummaries = [];

function renderChips() {
  const counts = monthCounts();
  $('#chips').innerHTML = counts.map(([id, n]) => `<button class="chip${selectedMonth === id ? ' active' : ''}" data-m="${id}">${monthShort(id)} <i>${n}</i></button>`).join('')
    + `<button class="chip${selectedMonth === null ? ' active' : ''}" data-m="">Tất cả <i>${slips.length}</i></button>`;
}
function render() {
  const q = $('#search').value, searching = !!q.trim();
  let hs = hits(q);
  if (searching) hs = onlyWithMatchedItems(hs);
  else if (selectedMonth !== null) hs = hs.filter(h => monthId(h.s) === selectedMonth);
  lastSummaries = searching ? packageSummaries(q, hs) : [];
  $('#summaries').innerHTML = lastSummaries.slice(0, 3).map(summaryCard).join('') + (lastSummaries.length > 3 ? `<div class="muted">+${lastSummaries.length - 3} loại kiện khớp khác</div>` : '');
  $('#hitCount').textContent = searching ? `${hs.length} phiếu khớp` : '';
  const emptyMsg = slips.length ? (searching ? 'Thử số RSI, mã kiện hoặc tên vật tư khác.' : `Không có phiếu trong ${selectedMonth !== null ? monthTitle(selectedMonth) : 'danh sách'}. Chọn "Tất cả" để xem mọi tháng.`) : 'Đang chờ dữ liệu. Kiểm tra mạng rồi bấm Đồng bộ.';
  $('#results').innerHTML = hs.length ? hs.map(h => card(h.s, h.items, q)).join('') : `<div class="empty"><div class="emptyIcon">⌕</div><b>Không tìm thấy dữ liệu</b><p>${esc(emptyMsg)}</p></div>`;
  $('#count').textContent = `${slips.length} phiếu`;
  renderChips();
  renderSuggest();
}
function renderSuggest() {
  const q = $('#search').value, list = showSuggest ? suggestions(q) : [];
  const label = { rsi: 'Số RSI', package: 'Mã kiện', desc: 'Tên hàng' };
  $('#suggest').classList.toggle('hidden', !list.length);
  $('#suggest').innerHTML = list.length ? `<div class="sgTitle">Gợi ý</div>` + list.map((g, i) => `<button class="sg" data-i="${i}"><b>${highlight(g.text, q)}</b><small>${label[g.kind]} · ${esc(g.sub)}</small></button>`).join('') : '';
  $('#suggest')._list = list;
}
function historyModal(item) {
  const recs = historyFor(item);
  $('#modal').classList.remove('hidden');
  $('#modal').innerHTML = `<div class="modalbox"><button class="close" id="closeModal">✕</button><div class="detailHead"><div><div class="eyebrow">LỊCH SỬ XUẤT</div><h2>${esc(item.packageNo)}</h2><p class="muted">${esc(item.desc)}${item.tag ? ' · Tag: ' + esc(item.tag) : ''}</p></div></div><div class="note">Đã xuất ${recs.length} lần · tổng ${esc(totalsText(recs))}</div><h3>Từng lần xuất theo RSI</h3><div class="itemTable">${recs.map(r => `<div class="detailItem hist" data-id="${esc(r.slip.id)}"><div><b>${esc(r.slip.rsiNo || '(chưa có số)')}</b><span>${esc(r.slip.requestDate || '-')}</span></div><strong>${esc(r.item.qty)} ${esc(r.item.unit)}</strong></div>`).join('')}</div></div>`;
  $('#closeModal').onclick = () => $('#modal').classList.add('hidden');
}
function detail(s) {
  const pages = (s.pages || []);
  $('#modal').classList.remove('hidden');
  $('#modal').innerHTML = `<div class="modalbox"><button class="close" id="closeModal">✕</button><div class="detailHead"><div><div class="eyebrow">PHIẾU RSI</div><h2>${esc(s.rsiNo || 'Chưa có số RSI')}</h2><p class="muted">${esc(s.requestDate || '-')}${s.project ? ' · ' + esc(s.project) : ''}</p></div><div class="detailStat"><b>${(s.items || []).length}</b><span>kiện</span></div><div class="detailStat"><b>${pages.length}</b><span>ảnh</span></div></div>${s.remark ? `<div class="note">${esc(s.remark)}</div>` : ''}<h3>Kiện hàng</h3><div class="itemTable">${(s.items || []).map(i => `<div class="detailItem"><div><b>${esc(i.packageNo || '(chưa có mã)')}</b><span>${esc(i.desc)}</span>${i.tag ? `<small>Tag: ${esc(i.tag)}</small>` : ''}</div><strong>${esc(i.qty)} ${esc(i.unit)}${i.actualQty ? `<small>Nhận: ${esc(i.actualQty)}</small>` : ''}</strong></div>`).join('') || '<div class="empty">Không có kiện hàng.</div>'}</div><h3>Thông tin xác nhận</h3><div class="people">${[['Người nhận', s.receivedBy], ['Ngày nhận', s.receivedDate], ['Requested By', s.requestedBy], ['Checked By', s.checkedBy], ['Confirmed By', s.confirmedBy], ['Approved By', s.approvedBy]].filter(x => x[1]).map(x => `<div><span>${esc(x[0])}</span><b>${esc(x[1])}</b></div>`).join('') || '<span class="muted">Không có dữ liệu.</span>'}</div><h3>Ảnh phiếu</h3><div class="gallery">${pages.map((u, i) => { const url = pageUrl(s, u); return url ? `<a href="${esc(url)}" target="_blank" rel="noreferrer"><img src="${esc(url)}" loading="lazy" alt="Trang ${i + 1}" onerror="this.parentElement.classList.add('broken')"><span>Trang ${i + 1}</span></a>` : `<div class="broken"><span>Trang ${i + 1} (chưa có trên Drive)</span></div>`; }).join('') || '<div class="muted">Không có ảnh.</div>'}</div></div>`;
  $('#closeModal').onclick = () => $('#modal').classList.add('hidden');
}
function show(view) {
  document.querySelectorAll('.view').forEach(v => v.classList.add('hidden'));
  $(`#${view}View`).classList.remove('hidden');
  document.querySelectorAll('.nav').forEach(n => n.classList.toggle('active', n.dataset.view === view));
  $('#pageTitle').textContent = view === 'home' ? 'Tra cứu RSI' : view === 'all' ? 'Danh sách phiếu' : 'Cài đặt';
  $('#pageSub').textContent = view === 'settings' ? 'Khu vực quản trị' : 'Tìm phiếu, mã kiện và thông tin vật tư';
}
function setSync(t, err = false) { $('#syncText').textContent = t; $('#syncDot').classList.toggle('error', err); $('#syncDot').classList.toggle('busy', !err && /Đang/.test(t)); }
function buildMonths() {
  const ids = [...new Set(slips.map(monthId))].sort((a, b) => b - a), cur = $('#monthFilter').value;
  $('#monthFilter').innerHTML = '<option value="">Tất cả tháng</option>' + ids.map(m => `<option value="${m}">${monthTitle(m)}</option>`).join('');
  $('#monthFilter').value = ids.map(String).includes(cur) ? cur : '';
}
function renderAll() {
  const q = Fuzzy.words($('#listSearch').value).join(''), m = $('#monthFilter').value;
  const a = slipsNewestFirst().filter(s => (!q || [s.rsiNo, s.project, s.requestDate, s.remark].some(v => Fuzzy.words(v).join('').includes(q))) && (!m || monthId(s) === +m));
  $('#allList').innerHTML = a.map(s => card(s)).join('') || '<div class="empty">Không có phiếu.</div>';
  $('#listCount').textContent = `${a.length}/${slips.length}`;
}
function refreshAll() {
  if (!monthInit) { selectedMonth = nowMonthId(); monthInit = true; }   // mặc định tháng hiện tại như bản iPhone
  buildMonths(); render(); renderAll();
}
async function sync() {
  setSync('Đang đồng bộ…');
  let r;
  try { r = await window.rsi.sync(); } catch (e) { r = { ok: false, message: e.message }; }
  if (r.ok) { slips = await window.rsi.load(); setSync(`Đã đồng bộ · ${r.count} phiếu`); refreshAll(); }
  else setSync(slips.length ? `Không đồng bộ được, đang dùng dữ liệu đã lưu (${r.message})` : r.message, true);
}

(async () => {
  slips = await window.rsi.load();
  const st = await window.rsi.getSettings();
  if (st.lastSync) setSync('Đồng bộ ' + new Date(st.lastSync).toLocaleString('vi-VN'));
  else setSync(slips.length ? 'Đang dùng dữ liệu trên máy' : 'Chưa có dữ liệu');
  refreshAll();
  sync();   // tự đồng bộ mỗi lần mở app, không cần khách thao tác

  document.querySelectorAll('.nav').forEach(n => n.onclick = () => show(n.dataset.view));
  $('#search').oninput = () => { showSuggest = true; render(); };
  $('#clear').onclick = () => { $('#search').value = ''; showSuggest = true; render(); };
  $('#chips').onclick = e => { const b = e.target.closest('.chip'); if (!b) return; selectedMonth = b.dataset.m === '' ? null : +b.dataset.m; render(); };
  $('#suggest').onclick = e => {
    const b = e.target.closest('.sg'); if (!b) return;
    $('#search').value = $('#suggest')._list[+b.dataset.i].text; showSuggest = false; render();
  };
  $('#summaries').onclick = e => { const c = e.target.closest('.sumCard'); if (c) historyModal(lastSummaries[+c.dataset.sum].item); };
  $('#syncBtn').onclick = sync;
  $('#listSearch').oninput = renderAll;
  $('#monthFilter').onchange = renderAll;
  document.addEventListener('click', e => {
    const h = e.target.closest('.hist'), c = e.target.closest('.card');
    const id = h ? h.dataset.id : c ? c.dataset.id : null;
    if (id === null) return;
    const s = slips.find(x => String(x.id) === id); if (s) detail(s);
  });

  const refreshSettings = async () => {
    const s = await window.rsi.getSettings();
    $('#firstSetup').classList.toggle('hidden', s.hasAdminPassword);
    $('#locked').classList.toggle('hidden', !s.hasAdminPassword || !!adminToken);
    $('#adminPanel').classList.toggle('hidden', !adminToken);
    if (s.hasAdminPassword && s.manifestUrl) $('#manifestUrl').value = s.manifestUrl;
  };
  await refreshSettings();
  $('#createAdmin').onclick = async () => {
    const a = $('#firstPass').value, b = $('#firstPass2').value;
    if (a !== b) { $('#setupMsg').innerHTML = '<div class="msg err">Hai mật khẩu không giống nhau.</div>'; return; }
    const r = await window.rsi.setupAdmin(a);
    if (!r.ok) { $('#setupMsg').innerHTML = `<div class="msg err">${esc(r.message)}</div>`; return; }
    adminToken = r.token; await refreshSettings(); $('#setupMsg').innerHTML = '<div class="msg ok">Đã tạo mật khẩu.</div>';
  };
  $('#unlock').onclick = async () => {
    const r = await window.rsi.loginAdmin($('#adminPass').value);
    if (!r.ok) { $('#loginMsg').innerHTML = '<div class="msg err">Sai mật khẩu.</div>'; return; }
    adminToken = r.token; $('#adminPass').value = ''; await refreshSettings(); $('#loginMsg').textContent = '';
  };
  $('#logout').onclick = async () => { await window.rsi.logoutAdmin(adminToken); adminToken = null; await refreshSettings(); };
  $('#saveSettings').onclick = async () => {
    const r = await window.rsi.setSettings(adminToken, { manifestUrl: $('#manifestUrl').value });
    $('#adminMsg').innerHTML = `<div class="msg ${r.ok ? 'ok' : 'err'}">${r.ok ? 'Đã lưu cấu hình.' : esc(r.message)}</div>`;
  };
  $('#changePass').onclick = async () => {
    const p = $('#newPass').value, r = await window.rsi.setSettings(adminToken, { adminPassword: p });
    $('#newPass').value = ''; $('#adminMsg').innerHTML = `<div class="msg ${r.ok ? 'ok' : 'err'}">${r.ok ? 'Đã đổi mật khẩu.' : esc(r.message)}</div>`;
  };
  $('#syncNow').onclick = sync;
  $('#openFolder').onclick = () => window.rsi.openDataFolder(adminToken);
})();
