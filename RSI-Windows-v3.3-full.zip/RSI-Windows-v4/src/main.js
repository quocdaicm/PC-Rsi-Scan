const { app, BrowserWindow, ipcMain, dialog, shell } = require('electron');
const path = require('path');
const fs = require('fs');
const https = require('https');
const crypto = require('crypto');

let win;
let adminSession = null;
const userDir = app.getPath('userData');
const storeFile = path.join(userDir, 'settings.json');
const cacheFile = path.join(userDir, 'slips.json');

function readJSON(file, fallback) { try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return fallback; } }
function writeJSON(file, value) { fs.mkdirSync(path.dirname(file), { recursive: true }); fs.writeFileSync(file, JSON.stringify(value, null, 2), 'utf8'); }
function getSettings() { return readJSON(storeFile, { adminHash: '', manifestUrl: '', lastSync: null, dataVersion: '' }); }
function hash(v) { return crypto.createHash('sha256').update(String(v)).digest('hex'); }
function newToken() { return crypto.randomBytes(32).toString('hex'); }
function requireAdmin(token) { return !!token && token === adminSession; }

const configFile = path.join(__dirname, '..', 'data', 'config.json');
// Nhận link chia sẻ Drive, link uc?id=..., hoặc chỉ ID file -> link tải trực tiếp
function toDownloadUrl(input) {
  const v = String(input || '').trim(); if (!v) return '';
  const m = v.match(/\/file\/d\/([\w-]{10,})/) || v.match(/[?&]id=([\w-]{10,})/);
  if (m) return `https://drive.google.com/uc?export=download&id=${m[1]}`;
  if (/^[\w-]{20,}$/.test(v)) return `https://drive.google.com/uc?export=download&id=${v}`;
  return v;
}
// Ưu tiên cấu hình admin đổi trong Cài đặt; không có thì dùng data/config.json cài sẵn trong bộ cài
function effectiveUrl() { const s = getSettings(); return toDownloadUrl(s.manifestUrl || readJSON(configFile, {}).manifestUrl); }

function fetchText(url, redirects = 0) {
  return new Promise((resolve, reject) => {
    if (!/^https:\/\//i.test(url)) return reject(new Error('Chỉ hỗ trợ URL HTTPS.'));
    if (redirects > 5) return reject(new Error('Quá nhiều chuyển hướng.'));
    https.get(url, { headers: { 'User-Agent': 'RSI-Windows/3.1', Accept: 'application/json,text/plain,*/*' } }, res => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        const next = new URL(res.headers.location, url).toString();
        return fetchText(next, redirects + 1).then(resolve, reject);
      }
      if (res.statusCode !== 200) return reject(new Error(`HTTP ${res.statusCode}`));
      let data = ''; res.setEncoding('utf8');
      res.on('data', c => data += c); res.on('end', () => resolve(data));
    }).on('error', reject).setTimeout(20000, function () { this.destroy(new Error('Hết thời gian chờ, kiểm tra mạng.')); });
  });
}
function normalizeSlip(s) {
  return {
    id: s.id || crypto.randomUUID(), rsiNo: s.rsiNo || '', requestDate: s.requestDate || '', project: s.project || '', remark: s.remark || '',
    items: Array.isArray(s.items) ? s.items.map(i => ({ id:i.id||crypto.randomUUID(), packageNo:i.packageNo||'', desc:i.desc||'', tag:i.tag||'', unit:i.unit||'', qty:i.qty||'', actualQty:i.actualQty??'' })) : [],
    pages: Array.isArray(s.pages) ? s.pages : [], createdAt: s.createdAt ?? '',
    driveFolderID: s.driveFolderID || '', driveJSONID: s.driveJSONID || '', driveImages: s.driveImages || {}, driveNames: s.driveNames || {},
    receivedBy: s.receivedBy || '', receivedDate: s.receivedDate || '', requestedBy: s.requestedBy || '', checkedBy: s.checkedBy || '', confirmedBy: s.confirmedBy || '', approvedBy: s.approvedBy || ''
  };
}
function loadData() {
  const local = readJSON(cacheFile, null); if (Array.isArray(local)) return local.map(normalizeSlip);
  const bundled = path.join(__dirname, '..', 'data', 'slips.json');
  return readJSON(bundled, []).map(normalizeSlip);
}
function createWindow() {
  win = new BrowserWindow({ width: 1360, height: 900, minWidth: 980, minHeight: 680, backgroundColor: '#f4f7f5', title: 'RSI', webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false, sandbox: true } });
  win.loadFile(path.join(__dirname, 'index.html'));
}
app.whenReady().then(() => { createWindow(); app.on('activate', () => { if (!BrowserWindow.getAllWindows().length) createWindow(); }); });
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });

ipcMain.handle('data:load', () => loadData());
ipcMain.handle('settings:get', () => { const s = getSettings(); return { hasAdminPassword: !!s.adminHash, manifestUrl: s.manifestUrl, hasSource: !!effectiveUrl(), lastSync: s.lastSync, dataVersion: s.dataVersion }; });
ipcMain.handle('admin:setup', (_, password) => {
  const s = getSettings(); if (s.adminHash) return { ok:false, message:'Mật khẩu admin đã được thiết lập.' };
  if (!password || String(password).length < 6) return { ok:false, message:'Mật khẩu tối thiểu 6 ký tự.' };
  s.adminHash = hash(password); writeJSON(storeFile, s); adminSession = newToken(); return { ok:true, token:adminSession };
});
ipcMain.handle('admin:login', (_, password) => { const s=getSettings(); if (!s.adminHash || hash(password)!==s.adminHash) return {ok:false}; adminSession=newToken(); return {ok:true, token:adminSession}; });
ipcMain.handle('admin:logout', (_, token) => { if (requireAdmin(token)) adminSession=null; return {ok:true}; });
ipcMain.handle('settings:set', (_, token, patch) => {
  if (!requireAdmin(token)) return {ok:false, message:'Phiên quản trị đã hết hạn.'};
  const s=getSettings();
  if (patch.manifestUrl !== undefined) s.manifestUrl=String(patch.manifestUrl||'').trim();
  if (patch.adminPassword !== undefined) { if (String(patch.adminPassword).length<6) return {ok:false,message:'Mật khẩu tối thiểu 6 ký tự.'}; s.adminHash=hash(patch.adminPassword); }
  writeJSON(storeFile,s); return {ok:true};
});
ipcMain.handle('sync:run', async () => {
  const s=getSettings(); const url=effectiveUrl(); if (!url) return {ok:false, code:'NO_URL', message:'Chưa có nguồn dữ liệu (data/config.json).'};
  try {
    const text=await fetchText(url);
    if (/^\s*</.test(text)) throw new Error('Drive trả về trang web, không phải JSON. Kiểm tra file index.json đã chia sẻ "Bất kỳ ai có liên kết".');
    const payload=JSON.parse(text);
    const data=Array.isArray(payload) ? payload : payload.slips;
    if (!Array.isArray(data)) throw new Error('Nguồn dữ liệu phải là mảng JSON hoặc object có trường slips.');
    const normalized=data.map(normalizeSlip); writeJSON(cacheFile, normalized);
    s.lastSync=new Date().toISOString(); s.dataVersion=String(payload.version ?? s.lastSync); writeJSON(storeFile,s);
    return {ok:true,count:normalized.length,lastSync:s.lastSync,dataVersion:s.dataVersion};
  } catch(e) { return {ok:false,message:e.message}; }
});
ipcMain.handle('app:openDataFolder', (_, token) => { if (!requireAdmin(token)) return {ok:false,message:'Cần quyền admin.'}; shell.openPath(userDir); return {ok:true}; });
ipcMain.handle('app:about', () => dialog.showMessageBox(win,{type:'info',title:'RSI Windows',message:'RSI Windows 3.1',detail:'Tra cứu RSI và tự đồng bộ index.json + ảnh từ Google Drive công khai.'}));
